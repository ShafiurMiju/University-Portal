﻿CREATE TABLE [dbo].[BloodGroup] (
    [bId]   INT          IDENTITY (1, 1) NOT NULL,
    [bName] VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([bId] ASC)
);

