﻿CREATE TABLE [dbo].[Nationality] (
    [nId]   INT          IDENTITY (1, 1) NOT NULL,
    [nName] VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([nId] ASC)
);

