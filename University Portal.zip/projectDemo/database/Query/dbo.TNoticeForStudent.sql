﻿CREATE TABLE [dbo].[TNoticeForStudent] (
    [Id]   INT            NOT NULL,
    [Sub]  VARCHAR (200)  NOT NULL,
    [Body] VARCHAR (1000) NOT NULL,
    [Date] DATETIME       NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

