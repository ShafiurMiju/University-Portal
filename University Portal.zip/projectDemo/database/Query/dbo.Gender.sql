﻿CREATE TABLE [dbo].[Gender] (
    [gId]   INT          IDENTITY (1, 1) NOT NULL,
    [gName] VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([gId] ASC)
);

