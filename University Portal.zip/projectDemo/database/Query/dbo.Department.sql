﻿CREATE TABLE [dbo].[Department] (
    [dId]   INT           IDENTITY (1, 1) NOT NULL,
    [dName] VARCHAR (150) NOT NULL,
    PRIMARY KEY CLUSTERED ([dId] ASC)
);

