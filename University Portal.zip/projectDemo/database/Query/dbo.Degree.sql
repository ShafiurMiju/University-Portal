﻿CREATE TABLE [dbo].[Degree] (
    [dId]   INT          IDENTITY (1, 1) NOT NULL,
    [dName] VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([dId] ASC)
);

