﻿CREATE TABLE [dbo].[Religion] (
    [rId]   INT          IDENTITY (1, 1) NOT NULL,
    [rName] VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([rId] ASC)
);

