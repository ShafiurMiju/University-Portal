﻿CREATE TABLE [dbo].[MaritalStatus] (
    [mId]   INT          IDENTITY (1, 1) NOT NULL,
    [mName] VARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([mId] ASC)
);

