﻿CREATE TABLE [dbo].[Program] (
    [pId]   INT           IDENTITY (1, 1) NOT NULL,
    [dId]   INT           NOT NULL,
    [pName] VARCHAR (150) NOT NULL,
    PRIMARY KEY CLUSTERED ([pId] ASC),
    FOREIGN KEY ([dId]) REFERENCES [dbo].[Department] ([dId])
);

