﻿CREATE TABLE [dbo].[Admin] (
    [Id]       INT          IDENTITY (10, 1) NOT NULL,
    [password] VARCHAR (50) NOT NULL,
    [name]     VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

