﻿CREATE TABLE [dbo].[CourseName] (
    [cId]   INT           IDENTITY (1, 1) NOT NULL,
    [pId]   INT           NOT NULL,
    [cName] VARCHAR (150) NOT NULL,
    PRIMARY KEY CLUSTERED ([cId] ASC),
    FOREIGN KEY ([pId]) REFERENCES [dbo].[Program] ([pId])
);

