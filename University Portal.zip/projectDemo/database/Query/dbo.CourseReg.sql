﻿CREATE TABLE [dbo].[CourseReg] (
    [SI]         INT           NOT NULL,
    [CourseName] VARCHAR (100) NOT NULL,
    [Section]    VARCHAR (50)  NOT NULL,
    [Faculty]    VARCHAR (100) NOT NULL,
    PRIMARY KEY CLUSTERED ([SI] ASC)
);

