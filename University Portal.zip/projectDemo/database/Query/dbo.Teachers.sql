﻿CREATE TABLE [dbo].[Teachers] (
    [Id]               INT           NOT NULL,
    [password]         NVARCHAR (50) NOT NULL,
    [name]             VARCHAR (50)  NOT NULL,
    [fatherName]       VARCHAR (50)  NOT NULL,
    [motherName]       VARCHAR (50)  NOT NULL,
    [dob]              DATE          NOT NULL,
    [gender]           VARCHAR (50)  NOT NULL,
    [presentAddress]   VARCHAR (250) NOT NULL,
    [permanentAddress] VARCHAR (250) NOT NULL,
    [contactNumber]    VARCHAR (50)  NOT NULL,
    [emailAddress]     VARCHAR (50)  NOT NULL,
    [nationality]      VARCHAR (50)  NOT NULL,
    [religion]         VARCHAR (50)  NOT NULL,
    [bloodGroup]       VARCHAR (50)  NOT NULL,
    [maritalStatus]    VARCHAR (50)  NOT NULL,
    [degree]           VARCHAR (150) NULL,
    [accountNumber]    VARCHAR (50)  NOT NULL,
    [joiningDate]      DATE          NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    UNIQUE NONCLUSTERED ([emailAddress] ASC)
);

