﻿
namespace projectDemo
{
    partial class studentProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(studentProfile));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel126 = new System.Windows.Forms.Panel();
            this.panel127 = new System.Windows.Forms.Panel();
            this.graduationDate = new System.Windows.Forms.Label();
            this.panel128 = new System.Windows.Forms.Panel();
            this.label52 = new System.Windows.Forms.Label();
            this.panel129 = new System.Windows.Forms.Panel();
            this.panel130 = new System.Windows.Forms.Panel();
            this.panel121 = new System.Windows.Forms.Panel();
            this.panel122 = new System.Windows.Forms.Panel();
            this.admissionDate = new System.Windows.Forms.Label();
            this.panel123 = new System.Windows.Forms.Panel();
            this.label50 = new System.Windows.Forms.Label();
            this.panel124 = new System.Windows.Forms.Panel();
            this.panel125 = new System.Windows.Forms.Panel();
            this.panel116 = new System.Windows.Forms.Panel();
            this.panel117 = new System.Windows.Forms.Panel();
            this.bloodGroup = new System.Windows.Forms.Label();
            this.panel118 = new System.Windows.Forms.Panel();
            this.label48 = new System.Windows.Forms.Label();
            this.panel119 = new System.Windows.Forms.Panel();
            this.panel120 = new System.Windows.Forms.Panel();
            this.panel111 = new System.Windows.Forms.Panel();
            this.panel112 = new System.Windows.Forms.Panel();
            this.maritalStatus = new System.Windows.Forms.Label();
            this.panel113 = new System.Windows.Forms.Panel();
            this.label46 = new System.Windows.Forms.Label();
            this.panel114 = new System.Windows.Forms.Panel();
            this.panel115 = new System.Windows.Forms.Panel();
            this.panel106 = new System.Windows.Forms.Panel();
            this.panel107 = new System.Windows.Forms.Panel();
            this.religion = new System.Windows.Forms.Label();
            this.panel108 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.panel109 = new System.Windows.Forms.Panel();
            this.panel110 = new System.Windows.Forms.Panel();
            this.panel101 = new System.Windows.Forms.Panel();
            this.panel102 = new System.Windows.Forms.Panel();
            this.nationality = new System.Windows.Forms.Label();
            this.panel103 = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.panel104 = new System.Windows.Forms.Panel();
            this.panel105 = new System.Windows.Forms.Panel();
            this.panel96 = new System.Windows.Forms.Panel();
            this.panel97 = new System.Windows.Forms.Panel();
            this.sex = new System.Windows.Forms.Label();
            this.panel98 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.panel99 = new System.Windows.Forms.Panel();
            this.panel100 = new System.Windows.Forms.Panel();
            this.panel91 = new System.Windows.Forms.Panel();
            this.panel92 = new System.Windows.Forms.Panel();
            this.dob = new System.Windows.Forms.Label();
            this.panel93 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.panel94 = new System.Windows.Forms.Panel();
            this.panel95 = new System.Windows.Forms.Panel();
            this.panel86 = new System.Windows.Forms.Panel();
            this.panel87 = new System.Windows.Forms.Panel();
            this.verifiedEmail = new System.Windows.Forms.Label();
            this.panel88 = new System.Windows.Forms.Panel();
            this.label36 = new System.Windows.Forms.Label();
            this.panel89 = new System.Windows.Forms.Panel();
            this.panel90 = new System.Windows.Forms.Panel();
            this.panel81 = new System.Windows.Forms.Panel();
            this.panel82 = new System.Windows.Forms.Panel();
            this.verifiedContact = new System.Windows.Forms.Label();
            this.panel83 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.panel84 = new System.Windows.Forms.Panel();
            this.panel85 = new System.Windows.Forms.Panel();
            this.panel76 = new System.Windows.Forms.Panel();
            this.panel77 = new System.Windows.Forms.Panel();
            this.permanentAddress = new System.Windows.Forms.Label();
            this.panel78 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.panel79 = new System.Windows.Forms.Panel();
            this.panel80 = new System.Windows.Forms.Panel();
            this.panel71 = new System.Windows.Forms.Panel();
            this.panel72 = new System.Windows.Forms.Panel();
            this.presentAddress = new System.Windows.Forms.Label();
            this.panel73 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.panel74 = new System.Windows.Forms.Panel();
            this.panel75 = new System.Windows.Forms.Panel();
            this.panel66 = new System.Windows.Forms.Panel();
            this.panel67 = new System.Windows.Forms.Panel();
            this.motherName = new System.Windows.Forms.Label();
            this.panel68 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.panel69 = new System.Windows.Forms.Panel();
            this.panel70 = new System.Windows.Forms.Panel();
            this.panel61 = new System.Windows.Forms.Panel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.fatherName = new System.Windows.Forms.Label();
            this.panel63 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.panel64 = new System.Windows.Forms.Panel();
            this.panel65 = new System.Windows.Forms.Panel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.panel57 = new System.Windows.Forms.Panel();
            this.elective = new System.Windows.Forms.Label();
            this.panel58 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.panel59 = new System.Windows.Forms.Panel();
            this.panel60 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.minor = new System.Windows.Forms.Label();
            this.panel53 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel54 = new System.Windows.Forms.Panel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.secondMajor = new System.Windows.Forms.Label();
            this.panel48 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.panel49 = new System.Windows.Forms.Panel();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.major = new System.Windows.Forms.Label();
            this.panel43 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.core = new System.Windows.Forms.Label();
            this.panel38 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.department = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.program = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.credit = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.cgpa = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.studentId = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.name = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel126.SuspendLayout();
            this.panel127.SuspendLayout();
            this.panel128.SuspendLayout();
            this.panel121.SuspendLayout();
            this.panel122.SuspendLayout();
            this.panel123.SuspendLayout();
            this.panel116.SuspendLayout();
            this.panel117.SuspendLayout();
            this.panel118.SuspendLayout();
            this.panel111.SuspendLayout();
            this.panel112.SuspendLayout();
            this.panel113.SuspendLayout();
            this.panel106.SuspendLayout();
            this.panel107.SuspendLayout();
            this.panel108.SuspendLayout();
            this.panel101.SuspendLayout();
            this.panel102.SuspendLayout();
            this.panel103.SuspendLayout();
            this.panel96.SuspendLayout();
            this.panel97.SuspendLayout();
            this.panel98.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel92.SuspendLayout();
            this.panel93.SuspendLayout();
            this.panel86.SuspendLayout();
            this.panel87.SuspendLayout();
            this.panel88.SuspendLayout();
            this.panel81.SuspendLayout();
            this.panel82.SuspendLayout();
            this.panel83.SuspendLayout();
            this.panel76.SuspendLayout();
            this.panel77.SuspendLayout();
            this.panel78.SuspendLayout();
            this.panel71.SuspendLayout();
            this.panel72.SuspendLayout();
            this.panel73.SuspendLayout();
            this.panel66.SuspendLayout();
            this.panel67.SuspendLayout();
            this.panel68.SuspendLayout();
            this.panel61.SuspendLayout();
            this.panel62.SuspendLayout();
            this.panel63.SuspendLayout();
            this.panel56.SuspendLayout();
            this.panel57.SuspendLayout();
            this.panel58.SuspendLayout();
            this.panel51.SuspendLayout();
            this.panel52.SuspendLayout();
            this.panel53.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(870, 619);
            this.panel1.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.AutoScroll = true;
            this.panel6.Controls.Add(this.panel126);
            this.panel6.Controls.Add(this.panel121);
            this.panel6.Controls.Add(this.panel116);
            this.panel6.Controls.Add(this.panel111);
            this.panel6.Controls.Add(this.panel106);
            this.panel6.Controls.Add(this.panel101);
            this.panel6.Controls.Add(this.panel96);
            this.panel6.Controls.Add(this.panel91);
            this.panel6.Controls.Add(this.panel86);
            this.panel6.Controls.Add(this.panel81);
            this.panel6.Controls.Add(this.panel76);
            this.panel6.Controls.Add(this.panel71);
            this.panel6.Controls.Add(this.panel66);
            this.panel6.Controls.Add(this.panel61);
            this.panel6.Controls.Add(this.panel56);
            this.panel6.Controls.Add(this.panel51);
            this.panel6.Controls.Add(this.panel46);
            this.panel6.Controls.Add(this.panel41);
            this.panel6.Controls.Add(this.panel36);
            this.panel6.Controls.Add(this.panel31);
            this.panel6.Controls.Add(this.panel26);
            this.panel6.Controls.Add(this.panel21);
            this.panel6.Controls.Add(this.panel16);
            this.panel6.Controls.Add(this.panel11);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(10, 50);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(607, 569);
            this.panel6.TabIndex = 14;
            // 
            // panel126
            // 
            this.panel126.Controls.Add(this.panel127);
            this.panel126.Controls.Add(this.panel128);
            this.panel126.Controls.Add(this.panel129);
            this.panel126.Controls.Add(this.panel130);
            this.panel126.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel126.Location = new System.Drawing.Point(0, 827);
            this.panel126.Name = "panel126";
            this.panel126.Size = new System.Drawing.Size(586, 35);
            this.panel126.TabIndex = 36;
            // 
            // panel127
            // 
            this.panel127.Controls.Add(this.graduationDate);
            this.panel127.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel127.Location = new System.Drawing.Point(120, 7);
            this.panel127.Name = "panel127";
            this.panel127.Size = new System.Drawing.Size(466, 27);
            this.panel127.TabIndex = 5;
            // 
            // graduationDate
            // 
            this.graduationDate.AutoSize = true;
            this.graduationDate.Dock = System.Windows.Forms.DockStyle.Left;
            this.graduationDate.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.graduationDate.Location = new System.Drawing.Point(0, 0);
            this.graduationDate.Name = "graduationDate";
            this.graduationDate.Size = new System.Drawing.Size(0, 23);
            this.graduationDate.TabIndex = 3;
            // 
            // panel128
            // 
            this.panel128.Controls.Add(this.label52);
            this.panel128.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel128.Location = new System.Drawing.Point(0, 7);
            this.panel128.Name = "panel128";
            this.panel128.Size = new System.Drawing.Size(120, 27);
            this.panel128.TabIndex = 4;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = System.Windows.Forms.DockStyle.Right;
            this.label52.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(-3, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(123, 23);
            this.label52.TabIndex = 3;
            this.label52.Text = "Graduation Date : ";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel129
            // 
            this.panel129.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel129.Location = new System.Drawing.Point(0, 0);
            this.panel129.Name = "panel129";
            this.panel129.Size = new System.Drawing.Size(586, 7);
            this.panel129.TabIndex = 2;
            // 
            // panel130
            // 
            this.panel130.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel130.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel130.Location = new System.Drawing.Point(0, 34);
            this.panel130.Name = "panel130";
            this.panel130.Size = new System.Drawing.Size(586, 1);
            this.panel130.TabIndex = 1;
            // 
            // panel121
            // 
            this.panel121.Controls.Add(this.panel122);
            this.panel121.Controls.Add(this.panel123);
            this.panel121.Controls.Add(this.panel124);
            this.panel121.Controls.Add(this.panel125);
            this.panel121.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel121.Location = new System.Drawing.Point(0, 792);
            this.panel121.Name = "panel121";
            this.panel121.Size = new System.Drawing.Size(586, 35);
            this.panel121.TabIndex = 35;
            // 
            // panel122
            // 
            this.panel122.Controls.Add(this.admissionDate);
            this.panel122.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel122.Location = new System.Drawing.Point(120, 7);
            this.panel122.Name = "panel122";
            this.panel122.Size = new System.Drawing.Size(466, 27);
            this.panel122.TabIndex = 5;
            // 
            // admissionDate
            // 
            this.admissionDate.AutoSize = true;
            this.admissionDate.Dock = System.Windows.Forms.DockStyle.Left;
            this.admissionDate.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.admissionDate.Location = new System.Drawing.Point(0, 0);
            this.admissionDate.Name = "admissionDate";
            this.admissionDate.Size = new System.Drawing.Size(0, 23);
            this.admissionDate.TabIndex = 3;
            // 
            // panel123
            // 
            this.panel123.Controls.Add(this.label50);
            this.panel123.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel123.Location = new System.Drawing.Point(0, 7);
            this.panel123.Name = "panel123";
            this.panel123.Size = new System.Drawing.Size(120, 27);
            this.panel123.TabIndex = 4;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Dock = System.Windows.Forms.DockStyle.Right;
            this.label50.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(118, 23);
            this.label50.TabIndex = 3;
            this.label50.Text = "Admission Date : ";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel124
            // 
            this.panel124.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel124.Location = new System.Drawing.Point(0, 0);
            this.panel124.Name = "panel124";
            this.panel124.Size = new System.Drawing.Size(586, 7);
            this.panel124.TabIndex = 2;
            // 
            // panel125
            // 
            this.panel125.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel125.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel125.Location = new System.Drawing.Point(0, 34);
            this.panel125.Name = "panel125";
            this.panel125.Size = new System.Drawing.Size(586, 1);
            this.panel125.TabIndex = 1;
            // 
            // panel116
            // 
            this.panel116.Controls.Add(this.panel117);
            this.panel116.Controls.Add(this.panel118);
            this.panel116.Controls.Add(this.panel119);
            this.panel116.Controls.Add(this.panel120);
            this.panel116.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel116.Location = new System.Drawing.Point(0, 757);
            this.panel116.Name = "panel116";
            this.panel116.Size = new System.Drawing.Size(586, 35);
            this.panel116.TabIndex = 34;
            // 
            // panel117
            // 
            this.panel117.Controls.Add(this.bloodGroup);
            this.panel117.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel117.Location = new System.Drawing.Point(120, 7);
            this.panel117.Name = "panel117";
            this.panel117.Size = new System.Drawing.Size(466, 27);
            this.panel117.TabIndex = 5;
            // 
            // bloodGroup
            // 
            this.bloodGroup.AutoSize = true;
            this.bloodGroup.Dock = System.Windows.Forms.DockStyle.Left;
            this.bloodGroup.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.bloodGroup.Location = new System.Drawing.Point(0, 0);
            this.bloodGroup.Name = "bloodGroup";
            this.bloodGroup.Size = new System.Drawing.Size(0, 23);
            this.bloodGroup.TabIndex = 3;
            // 
            // panel118
            // 
            this.panel118.Controls.Add(this.label48);
            this.panel118.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel118.Location = new System.Drawing.Point(0, 7);
            this.panel118.Name = "panel118";
            this.panel118.Size = new System.Drawing.Size(120, 27);
            this.panel118.TabIndex = 4;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = System.Windows.Forms.DockStyle.Right;
            this.label48.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(24, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(96, 23);
            this.label48.TabIndex = 3;
            this.label48.Text = "Blood Group : ";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel119
            // 
            this.panel119.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel119.Location = new System.Drawing.Point(0, 0);
            this.panel119.Name = "panel119";
            this.panel119.Size = new System.Drawing.Size(586, 7);
            this.panel119.TabIndex = 2;
            // 
            // panel120
            // 
            this.panel120.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel120.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel120.Location = new System.Drawing.Point(0, 34);
            this.panel120.Name = "panel120";
            this.panel120.Size = new System.Drawing.Size(586, 1);
            this.panel120.TabIndex = 1;
            // 
            // panel111
            // 
            this.panel111.Controls.Add(this.panel112);
            this.panel111.Controls.Add(this.panel113);
            this.panel111.Controls.Add(this.panel114);
            this.panel111.Controls.Add(this.panel115);
            this.panel111.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel111.Location = new System.Drawing.Point(0, 722);
            this.panel111.Name = "panel111";
            this.panel111.Size = new System.Drawing.Size(586, 35);
            this.panel111.TabIndex = 33;
            // 
            // panel112
            // 
            this.panel112.Controls.Add(this.maritalStatus);
            this.panel112.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel112.Location = new System.Drawing.Point(120, 7);
            this.panel112.Name = "panel112";
            this.panel112.Size = new System.Drawing.Size(466, 27);
            this.panel112.TabIndex = 5;
            // 
            // maritalStatus
            // 
            this.maritalStatus.AutoSize = true;
            this.maritalStatus.Dock = System.Windows.Forms.DockStyle.Left;
            this.maritalStatus.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.maritalStatus.Location = new System.Drawing.Point(0, 0);
            this.maritalStatus.Name = "maritalStatus";
            this.maritalStatus.Size = new System.Drawing.Size(0, 23);
            this.maritalStatus.TabIndex = 3;
            // 
            // panel113
            // 
            this.panel113.Controls.Add(this.label46);
            this.panel113.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel113.Location = new System.Drawing.Point(0, 7);
            this.panel113.Name = "panel113";
            this.panel113.Size = new System.Drawing.Size(120, 27);
            this.panel113.TabIndex = 4;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Dock = System.Windows.Forms.DockStyle.Right;
            this.label46.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(8, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(112, 23);
            this.label46.TabIndex = 3;
            this.label46.Text = "Marital Status : ";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel114
            // 
            this.panel114.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel114.Location = new System.Drawing.Point(0, 0);
            this.panel114.Name = "panel114";
            this.panel114.Size = new System.Drawing.Size(586, 7);
            this.panel114.TabIndex = 2;
            // 
            // panel115
            // 
            this.panel115.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel115.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel115.Location = new System.Drawing.Point(0, 34);
            this.panel115.Name = "panel115";
            this.panel115.Size = new System.Drawing.Size(586, 1);
            this.panel115.TabIndex = 1;
            // 
            // panel106
            // 
            this.panel106.Controls.Add(this.panel107);
            this.panel106.Controls.Add(this.panel108);
            this.panel106.Controls.Add(this.panel109);
            this.panel106.Controls.Add(this.panel110);
            this.panel106.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel106.Location = new System.Drawing.Point(0, 687);
            this.panel106.Name = "panel106";
            this.panel106.Size = new System.Drawing.Size(586, 35);
            this.panel106.TabIndex = 32;
            // 
            // panel107
            // 
            this.panel107.Controls.Add(this.religion);
            this.panel107.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel107.Location = new System.Drawing.Point(120, 7);
            this.panel107.Name = "panel107";
            this.panel107.Size = new System.Drawing.Size(466, 27);
            this.panel107.TabIndex = 5;
            // 
            // religion
            // 
            this.religion.AutoSize = true;
            this.religion.Dock = System.Windows.Forms.DockStyle.Left;
            this.religion.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.religion.Location = new System.Drawing.Point(0, 0);
            this.religion.Name = "religion";
            this.religion.Size = new System.Drawing.Size(0, 23);
            this.religion.TabIndex = 3;
            // 
            // panel108
            // 
            this.panel108.Controls.Add(this.label44);
            this.panel108.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel108.Location = new System.Drawing.Point(0, 7);
            this.panel108.Name = "panel108";
            this.panel108.Size = new System.Drawing.Size(120, 27);
            this.panel108.TabIndex = 4;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = System.Windows.Forms.DockStyle.Right;
            this.label44.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(48, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(72, 23);
            this.label44.TabIndex = 3;
            this.label44.Text = "Religion : ";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel109
            // 
            this.panel109.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel109.Location = new System.Drawing.Point(0, 0);
            this.panel109.Name = "panel109";
            this.panel109.Size = new System.Drawing.Size(586, 7);
            this.panel109.TabIndex = 2;
            // 
            // panel110
            // 
            this.panel110.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel110.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel110.Location = new System.Drawing.Point(0, 34);
            this.panel110.Name = "panel110";
            this.panel110.Size = new System.Drawing.Size(586, 1);
            this.panel110.TabIndex = 1;
            // 
            // panel101
            // 
            this.panel101.Controls.Add(this.panel102);
            this.panel101.Controls.Add(this.panel103);
            this.panel101.Controls.Add(this.panel104);
            this.panel101.Controls.Add(this.panel105);
            this.panel101.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel101.Location = new System.Drawing.Point(0, 652);
            this.panel101.Name = "panel101";
            this.panel101.Size = new System.Drawing.Size(586, 35);
            this.panel101.TabIndex = 31;
            // 
            // panel102
            // 
            this.panel102.Controls.Add(this.nationality);
            this.panel102.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel102.Location = new System.Drawing.Point(120, 7);
            this.panel102.Name = "panel102";
            this.panel102.Size = new System.Drawing.Size(466, 27);
            this.panel102.TabIndex = 5;
            // 
            // nationality
            // 
            this.nationality.AutoSize = true;
            this.nationality.Dock = System.Windows.Forms.DockStyle.Left;
            this.nationality.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.nationality.Location = new System.Drawing.Point(0, 0);
            this.nationality.Name = "nationality";
            this.nationality.Size = new System.Drawing.Size(0, 23);
            this.nationality.TabIndex = 3;
            // 
            // panel103
            // 
            this.panel103.Controls.Add(this.label42);
            this.panel103.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel103.Location = new System.Drawing.Point(0, 7);
            this.panel103.Name = "panel103";
            this.panel103.Size = new System.Drawing.Size(120, 27);
            this.panel103.TabIndex = 4;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Right;
            this.label42.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(31, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(89, 23);
            this.label42.TabIndex = 3;
            this.label42.Text = "Nationality : ";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel104
            // 
            this.panel104.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel104.Location = new System.Drawing.Point(0, 0);
            this.panel104.Name = "panel104";
            this.panel104.Size = new System.Drawing.Size(586, 7);
            this.panel104.TabIndex = 2;
            // 
            // panel105
            // 
            this.panel105.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel105.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel105.Location = new System.Drawing.Point(0, 34);
            this.panel105.Name = "panel105";
            this.panel105.Size = new System.Drawing.Size(586, 1);
            this.panel105.TabIndex = 1;
            // 
            // panel96
            // 
            this.panel96.Controls.Add(this.panel97);
            this.panel96.Controls.Add(this.panel98);
            this.panel96.Controls.Add(this.panel99);
            this.panel96.Controls.Add(this.panel100);
            this.panel96.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel96.Location = new System.Drawing.Point(0, 617);
            this.panel96.Name = "panel96";
            this.panel96.Size = new System.Drawing.Size(586, 35);
            this.panel96.TabIndex = 30;
            // 
            // panel97
            // 
            this.panel97.Controls.Add(this.sex);
            this.panel97.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel97.Location = new System.Drawing.Point(120, 7);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(466, 27);
            this.panel97.TabIndex = 5;
            // 
            // sex
            // 
            this.sex.AutoSize = true;
            this.sex.Dock = System.Windows.Forms.DockStyle.Left;
            this.sex.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.sex.Location = new System.Drawing.Point(0, 0);
            this.sex.Name = "sex";
            this.sex.Size = new System.Drawing.Size(0, 23);
            this.sex.TabIndex = 3;
            // 
            // panel98
            // 
            this.panel98.Controls.Add(this.label40);
            this.panel98.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel98.Location = new System.Drawing.Point(0, 7);
            this.panel98.Name = "panel98";
            this.panel98.Size = new System.Drawing.Size(120, 27);
            this.panel98.TabIndex = 4;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Right;
            this.label40.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(77, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(43, 23);
            this.label40.TabIndex = 3;
            this.label40.Text = "Sex : ";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel99
            // 
            this.panel99.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel99.Location = new System.Drawing.Point(0, 0);
            this.panel99.Name = "panel99";
            this.panel99.Size = new System.Drawing.Size(586, 7);
            this.panel99.TabIndex = 2;
            // 
            // panel100
            // 
            this.panel100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel100.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel100.Location = new System.Drawing.Point(0, 34);
            this.panel100.Name = "panel100";
            this.panel100.Size = new System.Drawing.Size(586, 1);
            this.panel100.TabIndex = 1;
            // 
            // panel91
            // 
            this.panel91.Controls.Add(this.panel92);
            this.panel91.Controls.Add(this.panel93);
            this.panel91.Controls.Add(this.panel94);
            this.panel91.Controls.Add(this.panel95);
            this.panel91.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel91.Location = new System.Drawing.Point(0, 582);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(586, 35);
            this.panel91.TabIndex = 29;
            // 
            // panel92
            // 
            this.panel92.Controls.Add(this.dob);
            this.panel92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel92.Location = new System.Drawing.Point(120, 7);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(466, 27);
            this.panel92.TabIndex = 5;
            // 
            // dob
            // 
            this.dob.AutoSize = true;
            this.dob.Dock = System.Windows.Forms.DockStyle.Left;
            this.dob.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.dob.Location = new System.Drawing.Point(0, 0);
            this.dob.Name = "dob";
            this.dob.Size = new System.Drawing.Size(0, 23);
            this.dob.TabIndex = 3;
            // 
            // panel93
            // 
            this.panel93.Controls.Add(this.label38);
            this.panel93.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel93.Location = new System.Drawing.Point(0, 7);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(120, 27);
            this.panel93.TabIndex = 4;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = System.Windows.Forms.DockStyle.Right;
            this.label38.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(74, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(46, 23);
            this.label38.TabIndex = 3;
            this.label38.Text = "DOB : ";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel94
            // 
            this.panel94.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel94.Location = new System.Drawing.Point(0, 0);
            this.panel94.Name = "panel94";
            this.panel94.Size = new System.Drawing.Size(586, 7);
            this.panel94.TabIndex = 2;
            // 
            // panel95
            // 
            this.panel95.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel95.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel95.Location = new System.Drawing.Point(0, 34);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(586, 1);
            this.panel95.TabIndex = 1;
            // 
            // panel86
            // 
            this.panel86.Controls.Add(this.panel87);
            this.panel86.Controls.Add(this.panel88);
            this.panel86.Controls.Add(this.panel89);
            this.panel86.Controls.Add(this.panel90);
            this.panel86.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel86.Location = new System.Drawing.Point(0, 547);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(586, 35);
            this.panel86.TabIndex = 28;
            // 
            // panel87
            // 
            this.panel87.Controls.Add(this.verifiedEmail);
            this.panel87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel87.Location = new System.Drawing.Point(120, 7);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(466, 27);
            this.panel87.TabIndex = 5;
            // 
            // verifiedEmail
            // 
            this.verifiedEmail.AutoSize = true;
            this.verifiedEmail.Dock = System.Windows.Forms.DockStyle.Left;
            this.verifiedEmail.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.verifiedEmail.Location = new System.Drawing.Point(0, 0);
            this.verifiedEmail.Name = "verifiedEmail";
            this.verifiedEmail.Size = new System.Drawing.Size(0, 23);
            this.verifiedEmail.TabIndex = 3;
            // 
            // panel88
            // 
            this.panel88.Controls.Add(this.label36);
            this.panel88.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel88.Location = new System.Drawing.Point(0, 7);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(120, 27);
            this.panel88.TabIndex = 4;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Right;
            this.label36.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(13, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(107, 23);
            this.label36.TabIndex = 3;
            this.label36.Text = "Verified Email : ";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel89
            // 
            this.panel89.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel89.Location = new System.Drawing.Point(0, 0);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(586, 7);
            this.panel89.TabIndex = 2;
            // 
            // panel90
            // 
            this.panel90.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel90.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel90.Location = new System.Drawing.Point(0, 34);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(586, 1);
            this.panel90.TabIndex = 1;
            // 
            // panel81
            // 
            this.panel81.Controls.Add(this.panel82);
            this.panel81.Controls.Add(this.panel83);
            this.panel81.Controls.Add(this.panel84);
            this.panel81.Controls.Add(this.panel85);
            this.panel81.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel81.Location = new System.Drawing.Point(0, 512);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(586, 35);
            this.panel81.TabIndex = 27;
            // 
            // panel82
            // 
            this.panel82.Controls.Add(this.verifiedContact);
            this.panel82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel82.Location = new System.Drawing.Point(120, 7);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(466, 27);
            this.panel82.TabIndex = 5;
            // 
            // verifiedContact
            // 
            this.verifiedContact.AutoSize = true;
            this.verifiedContact.Dock = System.Windows.Forms.DockStyle.Left;
            this.verifiedContact.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.verifiedContact.Location = new System.Drawing.Point(0, 0);
            this.verifiedContact.Name = "verifiedContact";
            this.verifiedContact.Size = new System.Drawing.Size(0, 23);
            this.verifiedContact.TabIndex = 3;
            // 
            // panel83
            // 
            this.panel83.Controls.Add(this.label34);
            this.panel83.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel83.Location = new System.Drawing.Point(0, 7);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(120, 27);
            this.panel83.TabIndex = 4;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Right;
            this.label34.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(0, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(120, 23);
            this.label34.TabIndex = 3;
            this.label34.Text = "Verified Contact : ";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel84
            // 
            this.panel84.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel84.Location = new System.Drawing.Point(0, 0);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(586, 7);
            this.panel84.TabIndex = 2;
            // 
            // panel85
            // 
            this.panel85.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel85.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel85.Location = new System.Drawing.Point(0, 34);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(586, 1);
            this.panel85.TabIndex = 1;
            // 
            // panel76
            // 
            this.panel76.Controls.Add(this.panel77);
            this.panel76.Controls.Add(this.panel78);
            this.panel76.Controls.Add(this.panel79);
            this.panel76.Controls.Add(this.panel80);
            this.panel76.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel76.Location = new System.Drawing.Point(0, 477);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(586, 35);
            this.panel76.TabIndex = 26;
            // 
            // panel77
            // 
            this.panel77.Controls.Add(this.permanentAddress);
            this.panel77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel77.Location = new System.Drawing.Point(120, 7);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(466, 27);
            this.panel77.TabIndex = 5;
            // 
            // permanentAddress
            // 
            this.permanentAddress.AutoSize = true;
            this.permanentAddress.Dock = System.Windows.Forms.DockStyle.Left;
            this.permanentAddress.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.permanentAddress.Location = new System.Drawing.Point(0, 0);
            this.permanentAddress.Name = "permanentAddress";
            this.permanentAddress.Size = new System.Drawing.Size(0, 23);
            this.permanentAddress.TabIndex = 3;
            // 
            // panel78
            // 
            this.panel78.Controls.Add(this.label32);
            this.panel78.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel78.Location = new System.Drawing.Point(0, 7);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(120, 27);
            this.panel78.TabIndex = 4;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Right;
            this.label32.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(-24, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(144, 23);
            this.label32.TabIndex = 3;
            this.label32.Text = "Permanent Address : ";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel79
            // 
            this.panel79.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel79.Location = new System.Drawing.Point(0, 0);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(586, 7);
            this.panel79.TabIndex = 2;
            // 
            // panel80
            // 
            this.panel80.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel80.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel80.Location = new System.Drawing.Point(0, 34);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(586, 1);
            this.panel80.TabIndex = 1;
            // 
            // panel71
            // 
            this.panel71.Controls.Add(this.panel72);
            this.panel71.Controls.Add(this.panel73);
            this.panel71.Controls.Add(this.panel74);
            this.panel71.Controls.Add(this.panel75);
            this.panel71.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel71.Location = new System.Drawing.Point(0, 442);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(586, 35);
            this.panel71.TabIndex = 25;
            // 
            // panel72
            // 
            this.panel72.Controls.Add(this.presentAddress);
            this.panel72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel72.Location = new System.Drawing.Point(120, 7);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(466, 27);
            this.panel72.TabIndex = 5;
            // 
            // presentAddress
            // 
            this.presentAddress.AutoSize = true;
            this.presentAddress.Dock = System.Windows.Forms.DockStyle.Left;
            this.presentAddress.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.presentAddress.Location = new System.Drawing.Point(0, 0);
            this.presentAddress.Name = "presentAddress";
            this.presentAddress.Size = new System.Drawing.Size(0, 23);
            this.presentAddress.TabIndex = 3;
            // 
            // panel73
            // 
            this.panel73.Controls.Add(this.label30);
            this.panel73.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel73.Location = new System.Drawing.Point(0, 7);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(120, 27);
            this.panel73.TabIndex = 4;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Right;
            this.label30.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(-4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(124, 23);
            this.label30.TabIndex = 3;
            this.label30.Text = "Present Address : ";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel74
            // 
            this.panel74.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel74.Location = new System.Drawing.Point(0, 0);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(586, 7);
            this.panel74.TabIndex = 2;
            // 
            // panel75
            // 
            this.panel75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel75.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel75.Location = new System.Drawing.Point(0, 34);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(586, 1);
            this.panel75.TabIndex = 1;
            // 
            // panel66
            // 
            this.panel66.Controls.Add(this.panel67);
            this.panel66.Controls.Add(this.panel68);
            this.panel66.Controls.Add(this.panel69);
            this.panel66.Controls.Add(this.panel70);
            this.panel66.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel66.Location = new System.Drawing.Point(0, 407);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(586, 35);
            this.panel66.TabIndex = 24;
            // 
            // panel67
            // 
            this.panel67.Controls.Add(this.motherName);
            this.panel67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel67.Location = new System.Drawing.Point(120, 7);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(466, 27);
            this.panel67.TabIndex = 5;
            // 
            // motherName
            // 
            this.motherName.AutoSize = true;
            this.motherName.Dock = System.Windows.Forms.DockStyle.Left;
            this.motherName.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.motherName.Location = new System.Drawing.Point(0, 0);
            this.motherName.Name = "motherName";
            this.motherName.Size = new System.Drawing.Size(0, 23);
            this.motherName.TabIndex = 3;
            // 
            // panel68
            // 
            this.panel68.Controls.Add(this.label28);
            this.panel68.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel68.Location = new System.Drawing.Point(0, 7);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(120, 27);
            this.panel68.TabIndex = 4;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Right;
            this.label28.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(16, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(104, 23);
            this.label28.TabIndex = 3;
            this.label28.Text = "Mother Name : ";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel69
            // 
            this.panel69.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel69.Location = new System.Drawing.Point(0, 0);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(586, 7);
            this.panel69.TabIndex = 2;
            // 
            // panel70
            // 
            this.panel70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel70.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel70.Location = new System.Drawing.Point(0, 34);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(586, 1);
            this.panel70.TabIndex = 1;
            // 
            // panel61
            // 
            this.panel61.Controls.Add(this.panel62);
            this.panel61.Controls.Add(this.panel63);
            this.panel61.Controls.Add(this.panel64);
            this.panel61.Controls.Add(this.panel65);
            this.panel61.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel61.Location = new System.Drawing.Point(0, 372);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(586, 35);
            this.panel61.TabIndex = 23;
            // 
            // panel62
            // 
            this.panel62.Controls.Add(this.fatherName);
            this.panel62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel62.Location = new System.Drawing.Point(120, 7);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(466, 27);
            this.panel62.TabIndex = 5;
            // 
            // fatherName
            // 
            this.fatherName.AutoSize = true;
            this.fatherName.Dock = System.Windows.Forms.DockStyle.Left;
            this.fatherName.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.fatherName.Location = new System.Drawing.Point(0, 0);
            this.fatherName.Name = "fatherName";
            this.fatherName.Size = new System.Drawing.Size(0, 23);
            this.fatherName.TabIndex = 3;
            // 
            // panel63
            // 
            this.panel63.Controls.Add(this.label26);
            this.panel63.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel63.Location = new System.Drawing.Point(0, 7);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(120, 27);
            this.panel63.TabIndex = 4;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Right;
            this.label26.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(19, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(101, 23);
            this.label26.TabIndex = 3;
            this.label26.Text = "Father Name : ";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel64
            // 
            this.panel64.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel64.Location = new System.Drawing.Point(0, 0);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(586, 7);
            this.panel64.TabIndex = 2;
            // 
            // panel65
            // 
            this.panel65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel65.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel65.Location = new System.Drawing.Point(0, 34);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(586, 1);
            this.panel65.TabIndex = 1;
            // 
            // panel56
            // 
            this.panel56.Controls.Add(this.panel57);
            this.panel56.Controls.Add(this.panel58);
            this.panel56.Controls.Add(this.panel59);
            this.panel56.Controls.Add(this.panel60);
            this.panel56.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel56.Location = new System.Drawing.Point(0, 337);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(586, 35);
            this.panel56.TabIndex = 22;
            // 
            // panel57
            // 
            this.panel57.Controls.Add(this.elective);
            this.panel57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel57.Location = new System.Drawing.Point(120, 7);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(466, 27);
            this.panel57.TabIndex = 5;
            // 
            // elective
            // 
            this.elective.AutoSize = true;
            this.elective.Dock = System.Windows.Forms.DockStyle.Left;
            this.elective.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.elective.Location = new System.Drawing.Point(0, 0);
            this.elective.Name = "elective";
            this.elective.Size = new System.Drawing.Size(0, 23);
            this.elective.TabIndex = 3;
            // 
            // panel58
            // 
            this.panel58.Controls.Add(this.label24);
            this.panel58.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel58.Location = new System.Drawing.Point(0, 7);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(120, 27);
            this.panel58.TabIndex = 4;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Right;
            this.label24.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(51, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(69, 23);
            this.label24.TabIndex = 3;
            this.label24.Text = "Elective : ";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel59
            // 
            this.panel59.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel59.Location = new System.Drawing.Point(0, 0);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(586, 7);
            this.panel59.TabIndex = 2;
            // 
            // panel60
            // 
            this.panel60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel60.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel60.Location = new System.Drawing.Point(0, 34);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(586, 1);
            this.panel60.TabIndex = 1;
            // 
            // panel51
            // 
            this.panel51.Controls.Add(this.panel52);
            this.panel51.Controls.Add(this.panel53);
            this.panel51.Controls.Add(this.panel54);
            this.panel51.Controls.Add(this.panel55);
            this.panel51.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel51.Location = new System.Drawing.Point(0, 302);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(586, 35);
            this.panel51.TabIndex = 21;
            // 
            // panel52
            // 
            this.panel52.Controls.Add(this.minor);
            this.panel52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel52.Location = new System.Drawing.Point(120, 7);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(466, 27);
            this.panel52.TabIndex = 5;
            // 
            // minor
            // 
            this.minor.AutoSize = true;
            this.minor.Dock = System.Windows.Forms.DockStyle.Left;
            this.minor.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.minor.Location = new System.Drawing.Point(0, 0);
            this.minor.Name = "minor";
            this.minor.Size = new System.Drawing.Size(0, 23);
            this.minor.TabIndex = 3;
            // 
            // panel53
            // 
            this.panel53.Controls.Add(this.label22);
            this.panel53.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel53.Location = new System.Drawing.Point(0, 7);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(120, 27);
            this.panel53.TabIndex = 4;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Right;
            this.label22.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(63, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 23);
            this.label22.TabIndex = 3;
            this.label22.Text = "Minor : ";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel54
            // 
            this.panel54.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel54.Location = new System.Drawing.Point(0, 0);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(586, 7);
            this.panel54.TabIndex = 2;
            // 
            // panel55
            // 
            this.panel55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel55.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel55.Location = new System.Drawing.Point(0, 34);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(586, 1);
            this.panel55.TabIndex = 1;
            // 
            // panel46
            // 
            this.panel46.Controls.Add(this.panel47);
            this.panel46.Controls.Add(this.panel48);
            this.panel46.Controls.Add(this.panel49);
            this.panel46.Controls.Add(this.panel50);
            this.panel46.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel46.Location = new System.Drawing.Point(0, 267);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(586, 35);
            this.panel46.TabIndex = 20;
            // 
            // panel47
            // 
            this.panel47.Controls.Add(this.secondMajor);
            this.panel47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel47.Location = new System.Drawing.Point(120, 7);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(466, 27);
            this.panel47.TabIndex = 5;
            // 
            // secondMajor
            // 
            this.secondMajor.AutoSize = true;
            this.secondMajor.Dock = System.Windows.Forms.DockStyle.Left;
            this.secondMajor.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.secondMajor.Location = new System.Drawing.Point(0, 0);
            this.secondMajor.Name = "secondMajor";
            this.secondMajor.Size = new System.Drawing.Size(0, 23);
            this.secondMajor.TabIndex = 3;
            // 
            // panel48
            // 
            this.panel48.Controls.Add(this.label20);
            this.panel48.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel48.Location = new System.Drawing.Point(0, 7);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(120, 27);
            this.panel48.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Right;
            this.label20.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(14, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(106, 23);
            this.label20.TabIndex = 3;
            this.label20.Text = "Second Major : ";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel49
            // 
            this.panel49.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel49.Location = new System.Drawing.Point(0, 0);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(586, 7);
            this.panel49.TabIndex = 2;
            // 
            // panel50
            // 
            this.panel50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel50.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel50.Location = new System.Drawing.Point(0, 34);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(586, 1);
            this.panel50.TabIndex = 1;
            // 
            // panel41
            // 
            this.panel41.Controls.Add(this.panel42);
            this.panel41.Controls.Add(this.panel43);
            this.panel41.Controls.Add(this.panel44);
            this.panel41.Controls.Add(this.panel45);
            this.panel41.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel41.Location = new System.Drawing.Point(0, 232);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(586, 35);
            this.panel41.TabIndex = 19;
            // 
            // panel42
            // 
            this.panel42.Controls.Add(this.major);
            this.panel42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel42.Location = new System.Drawing.Point(120, 7);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(466, 27);
            this.panel42.TabIndex = 5;
            // 
            // major
            // 
            this.major.AutoSize = true;
            this.major.Dock = System.Windows.Forms.DockStyle.Left;
            this.major.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.major.Location = new System.Drawing.Point(0, 0);
            this.major.Name = "major";
            this.major.Size = new System.Drawing.Size(0, 23);
            this.major.TabIndex = 3;
            // 
            // panel43
            // 
            this.panel43.Controls.Add(this.label18);
            this.panel43.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel43.Location = new System.Drawing.Point(0, 7);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(120, 27);
            this.panel43.TabIndex = 4;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Right;
            this.label18.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(63, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 23);
            this.label18.TabIndex = 3;
            this.label18.Text = "Major : ";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel44
            // 
            this.panel44.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel44.Location = new System.Drawing.Point(0, 0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(586, 7);
            this.panel44.TabIndex = 2;
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel45.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel45.Location = new System.Drawing.Point(0, 34);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(586, 1);
            this.panel45.TabIndex = 1;
            // 
            // panel36
            // 
            this.panel36.Controls.Add(this.panel37);
            this.panel36.Controls.Add(this.panel38);
            this.panel36.Controls.Add(this.panel39);
            this.panel36.Controls.Add(this.panel40);
            this.panel36.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel36.Location = new System.Drawing.Point(0, 197);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(586, 35);
            this.panel36.TabIndex = 18;
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.core);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel37.Location = new System.Drawing.Point(120, 7);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(466, 27);
            this.panel37.TabIndex = 5;
            // 
            // core
            // 
            this.core.AutoSize = true;
            this.core.Dock = System.Windows.Forms.DockStyle.Left;
            this.core.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.core.Location = new System.Drawing.Point(0, 0);
            this.core.Name = "core";
            this.core.Size = new System.Drawing.Size(0, 23);
            this.core.TabIndex = 3;
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.label16);
            this.panel38.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel38.Location = new System.Drawing.Point(0, 7);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(120, 27);
            this.panel38.TabIndex = 4;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Right;
            this.label16.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(71, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 23);
            this.label16.TabIndex = 3;
            this.label16.Text = "Core : ";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel39
            // 
            this.panel39.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel39.Location = new System.Drawing.Point(0, 0);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(586, 7);
            this.panel39.TabIndex = 2;
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel40.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel40.Location = new System.Drawing.Point(0, 34);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(586, 1);
            this.panel40.TabIndex = 1;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.panel32);
            this.panel31.Controls.Add(this.panel33);
            this.panel31.Controls.Add(this.panel34);
            this.panel31.Controls.Add(this.panel35);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel31.Location = new System.Drawing.Point(0, 162);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(586, 35);
            this.panel31.TabIndex = 17;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.department);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel32.Location = new System.Drawing.Point(120, 7);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(466, 27);
            this.panel32.TabIndex = 5;
            // 
            // department
            // 
            this.department.AutoSize = true;
            this.department.Dock = System.Windows.Forms.DockStyle.Left;
            this.department.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.department.Location = new System.Drawing.Point(0, 0);
            this.department.Name = "department";
            this.department.Size = new System.Drawing.Size(0, 23);
            this.department.TabIndex = 3;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.label14);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel33.Location = new System.Drawing.Point(0, 7);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(120, 27);
            this.panel33.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Right;
            this.label14.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(25, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(95, 23);
            this.label14.TabIndex = 3;
            this.label14.Text = "Department : ";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel34
            // 
            this.panel34.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel34.Location = new System.Drawing.Point(0, 0);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(586, 7);
            this.panel34.TabIndex = 2;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel35.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel35.Location = new System.Drawing.Point(0, 34);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(586, 1);
            this.panel35.TabIndex = 1;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.panel27);
            this.panel26.Controls.Add(this.panel28);
            this.panel26.Controls.Add(this.panel29);
            this.panel26.Controls.Add(this.panel30);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel26.Location = new System.Drawing.Point(0, 127);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(586, 35);
            this.panel26.TabIndex = 16;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.program);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(120, 7);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(466, 27);
            this.panel27.TabIndex = 5;
            // 
            // program
            // 
            this.program.AutoSize = true;
            this.program.Dock = System.Windows.Forms.DockStyle.Left;
            this.program.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.program.Location = new System.Drawing.Point(0, 0);
            this.program.Name = "program";
            this.program.Size = new System.Drawing.Size(0, 23);
            this.program.TabIndex = 3;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.label12);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel28.Location = new System.Drawing.Point(0, 7);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(120, 27);
            this.panel28.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Right;
            this.label12.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(44, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 23);
            this.label12.TabIndex = 3;
            this.label12.Text = "Program : ";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel29
            // 
            this.panel29.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel29.Location = new System.Drawing.Point(0, 0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(586, 7);
            this.panel29.TabIndex = 2;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel30.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel30.Location = new System.Drawing.Point(0, 34);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(586, 1);
            this.panel30.TabIndex = 1;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Controls.Add(this.panel23);
            this.panel21.Controls.Add(this.panel24);
            this.panel21.Controls.Add(this.panel25);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel21.Location = new System.Drawing.Point(0, 92);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(586, 35);
            this.panel21.TabIndex = 15;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.credit);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(120, 7);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(466, 27);
            this.panel22.TabIndex = 5;
            // 
            // credit
            // 
            this.credit.AutoSize = true;
            this.credit.Dock = System.Windows.Forms.DockStyle.Left;
            this.credit.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.credit.Location = new System.Drawing.Point(0, 0);
            this.credit.Name = "credit";
            this.credit.Size = new System.Drawing.Size(0, 23);
            this.credit.TabIndex = 3;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.label10);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel23.Location = new System.Drawing.Point(0, 7);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(120, 27);
            this.panel23.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Right;
            this.label10.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(61, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 23);
            this.label10.TabIndex = 3;
            this.label10.Text = "Credit : ";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel24
            // 
            this.panel24.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel24.Location = new System.Drawing.Point(0, 0);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(586, 7);
            this.panel24.TabIndex = 2;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel25.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel25.Location = new System.Drawing.Point(0, 34);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(586, 1);
            this.panel25.TabIndex = 1;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Controls.Add(this.panel18);
            this.panel16.Controls.Add(this.panel19);
            this.panel16.Controls.Add(this.panel20);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(0, 57);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(586, 35);
            this.panel16.TabIndex = 14;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.cgpa);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(120, 7);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(466, 27);
            this.panel17.TabIndex = 5;
            // 
            // cgpa
            // 
            this.cgpa.AutoSize = true;
            this.cgpa.Dock = System.Windows.Forms.DockStyle.Left;
            this.cgpa.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.cgpa.Location = new System.Drawing.Point(0, 0);
            this.cgpa.Name = "cgpa";
            this.cgpa.Size = new System.Drawing.Size(0, 23);
            this.cgpa.TabIndex = 3;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.label8);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel18.Location = new System.Drawing.Point(0, 7);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(120, 27);
            this.panel18.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Right;
            this.label8.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(68, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 23);
            this.label8.TabIndex = 3;
            this.label8.Text = "CGPA : ";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel19
            // 
            this.panel19.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel19.Location = new System.Drawing.Point(0, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(586, 7);
            this.panel19.TabIndex = 2;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel20.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel20.Location = new System.Drawing.Point(0, 34);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(586, 1);
            this.panel20.TabIndex = 1;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.panel14);
            this.panel11.Controls.Add(this.panel15);
            this.panel11.Controls.Add(this.panel13);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 22);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(586, 35);
            this.panel11.TabIndex = 13;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.studentId);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(120, 7);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(466, 27);
            this.panel14.TabIndex = 5;
            // 
            // studentId
            // 
            this.studentId.AutoSize = true;
            this.studentId.Dock = System.Windows.Forms.DockStyle.Left;
            this.studentId.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.studentId.Location = new System.Drawing.Point(0, 0);
            this.studentId.Name = "studentId";
            this.studentId.Size = new System.Drawing.Size(0, 23);
            this.studentId.TabIndex = 3;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label6);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel15.Location = new System.Drawing.Point(0, 7);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(120, 27);
            this.panel15.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Right;
            this.label6.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(34, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 23);
            this.label6.TabIndex = 3;
            this.label6.Text = "Student Id : ";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel13
            // 
            this.panel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel13.Location = new System.Drawing.Point(0, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(586, 7);
            this.panel13.TabIndex = 2;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel12.Location = new System.Drawing.Point(0, 34);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(586, 1);
            this.panel12.TabIndex = 1;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(586, 22);
            this.panel9.TabIndex = 12;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(0, 21);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(586, 1);
            this.panel10.TabIndex = 1;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.pictureBox1);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel7.Location = new System.Drawing.Point(617, 50);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(243, 569);
            this.panel7.TabIndex = 13;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(6, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(231, 225);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Controls.Add(this.name);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(10, 10);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(850, 40);
            this.panel5.TabIndex = 11;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 39);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(850, 1);
            this.panel8.TabIndex = 1;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(0, 10);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(66, 22);
            this.name.TabIndex = 0;
            this.name.Text = "NAME";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(860, 10);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 609);
            this.panel4.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 10);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 609);
            this.panel2.TabIndex = 9;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(870, 10);
            this.panel3.TabIndex = 8;
            // 
            // studentProfile
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(870, 619);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "studentProfile";
            this.Text = "studentProfile";
            this.Load += new System.EventHandler(this.studentProfile_Load);
            this.panel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel126.ResumeLayout(false);
            this.panel127.ResumeLayout(false);
            this.panel127.PerformLayout();
            this.panel128.ResumeLayout(false);
            this.panel128.PerformLayout();
            this.panel121.ResumeLayout(false);
            this.panel122.ResumeLayout(false);
            this.panel122.PerformLayout();
            this.panel123.ResumeLayout(false);
            this.panel123.PerformLayout();
            this.panel116.ResumeLayout(false);
            this.panel117.ResumeLayout(false);
            this.panel117.PerformLayout();
            this.panel118.ResumeLayout(false);
            this.panel118.PerformLayout();
            this.panel111.ResumeLayout(false);
            this.panel112.ResumeLayout(false);
            this.panel112.PerformLayout();
            this.panel113.ResumeLayout(false);
            this.panel113.PerformLayout();
            this.panel106.ResumeLayout(false);
            this.panel107.ResumeLayout(false);
            this.panel107.PerformLayout();
            this.panel108.ResumeLayout(false);
            this.panel108.PerformLayout();
            this.panel101.ResumeLayout(false);
            this.panel102.ResumeLayout(false);
            this.panel102.PerformLayout();
            this.panel103.ResumeLayout(false);
            this.panel103.PerformLayout();
            this.panel96.ResumeLayout(false);
            this.panel97.ResumeLayout(false);
            this.panel97.PerformLayout();
            this.panel98.ResumeLayout(false);
            this.panel98.PerformLayout();
            this.panel91.ResumeLayout(false);
            this.panel92.ResumeLayout(false);
            this.panel92.PerformLayout();
            this.panel93.ResumeLayout(false);
            this.panel93.PerformLayout();
            this.panel86.ResumeLayout(false);
            this.panel87.ResumeLayout(false);
            this.panel87.PerformLayout();
            this.panel88.ResumeLayout(false);
            this.panel88.PerformLayout();
            this.panel81.ResumeLayout(false);
            this.panel82.ResumeLayout(false);
            this.panel82.PerformLayout();
            this.panel83.ResumeLayout(false);
            this.panel83.PerformLayout();
            this.panel76.ResumeLayout(false);
            this.panel77.ResumeLayout(false);
            this.panel77.PerformLayout();
            this.panel78.ResumeLayout(false);
            this.panel78.PerformLayout();
            this.panel71.ResumeLayout(false);
            this.panel72.ResumeLayout(false);
            this.panel72.PerformLayout();
            this.panel73.ResumeLayout(false);
            this.panel73.PerformLayout();
            this.panel66.ResumeLayout(false);
            this.panel67.ResumeLayout(false);
            this.panel67.PerformLayout();
            this.panel68.ResumeLayout(false);
            this.panel68.PerformLayout();
            this.panel61.ResumeLayout(false);
            this.panel62.ResumeLayout(false);
            this.panel62.PerformLayout();
            this.panel63.ResumeLayout(false);
            this.panel63.PerformLayout();
            this.panel56.ResumeLayout(false);
            this.panel57.ResumeLayout(false);
            this.panel57.PerformLayout();
            this.panel58.ResumeLayout(false);
            this.panel58.PerformLayout();
            this.panel51.ResumeLayout(false);
            this.panel52.ResumeLayout(false);
            this.panel52.PerformLayout();
            this.panel53.ResumeLayout(false);
            this.panel53.PerformLayout();
            this.panel46.ResumeLayout(false);
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label studentId;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Label core;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Label department;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label program;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label credit;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label cgpa;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel126;
        private System.Windows.Forms.Panel panel127;
        private System.Windows.Forms.Label graduationDate;
        private System.Windows.Forms.Panel panel128;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Panel panel129;
        private System.Windows.Forms.Panel panel130;
        private System.Windows.Forms.Panel panel121;
        private System.Windows.Forms.Panel panel122;
        private System.Windows.Forms.Label admissionDate;
        private System.Windows.Forms.Panel panel123;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Panel panel124;
        private System.Windows.Forms.Panel panel125;
        private System.Windows.Forms.Panel panel116;
        private System.Windows.Forms.Panel panel117;
        private System.Windows.Forms.Label bloodGroup;
        private System.Windows.Forms.Panel panel118;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Panel panel119;
        private System.Windows.Forms.Panel panel120;
        private System.Windows.Forms.Panel panel111;
        private System.Windows.Forms.Panel panel112;
        private System.Windows.Forms.Label maritalStatus;
        private System.Windows.Forms.Panel panel113;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panel114;
        private System.Windows.Forms.Panel panel115;
        private System.Windows.Forms.Panel panel106;
        private System.Windows.Forms.Panel panel107;
        private System.Windows.Forms.Label religion;
        private System.Windows.Forms.Panel panel108;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Panel panel109;
        private System.Windows.Forms.Panel panel110;
        private System.Windows.Forms.Panel panel101;
        private System.Windows.Forms.Panel panel102;
        private System.Windows.Forms.Label nationality;
        private System.Windows.Forms.Panel panel103;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel104;
        private System.Windows.Forms.Panel panel105;
        private System.Windows.Forms.Panel panel96;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.Label sex;
        private System.Windows.Forms.Panel panel98;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Panel panel99;
        private System.Windows.Forms.Panel panel100;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Label dob;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel94;
        private System.Windows.Forms.Panel panel95;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.Label verifiedEmail;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.Label verifiedContact;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.Label permanentAddress;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Label presentAddress;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Label motherName;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Label fatherName;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Label elective;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Label minor;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Label secondMajor;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Label major;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel45;
    }
}