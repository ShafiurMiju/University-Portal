﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class ForgetPass1 : Form
    {

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
            (int Left, int Top, int Right, int Bottom, int Width, int Height);

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);
        public ForgetPass1()
        {
            InitializeComponent();
            this.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.Width, this.Height, 20, 20));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ForgetPass forgetPass  = new ForgetPass();
            this.Hide();
            forgetPass.ShowDialog();
            this.Close();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel12_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, 0xA1, 0x2, 0);
            }
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (customTextBox1.Texts == "")
                {
                    label9.Visible = true;
                }
                else
                {                  
                    try
                    {
                        if (ForgetPass.randomcode == (customTextBox1.Texts).ToString())
                        {
                            ForgetPass.to = customTextBox1.Texts;

                            ForgetPass2 forgetPass2 = new ForgetPass2();
                            this.Hide();
                            forgetPass2.ShowDialog();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Wrong Code");
                        }
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }

            }
            catch (Exception ex)
            {
                if (customTextBox1.Texts == "")
                {
                    label9.Visible = true;
                }
            }

        }

        private void customTextBox1__TextChanged(object sender, EventArgs e)
        {
            if (label9.Visible == true)
            {
                label9.Visible = false;
            }
        }
    }
}
