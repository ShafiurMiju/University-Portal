﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class ForgetPass : Form
    {

        string pattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|" + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)" + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";
        public static string randomcode;
        public static string to;

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
            (int Left, int Top, int Right, int Bottom, int Width, int Height);

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);
        public ForgetPass()
        {
            InitializeComponent();
            this.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.Width, this.Height, 20, 20));
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel12_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, 0xA1, 0x2, 0);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
            this.Close();
        }

        public static string email;
        public static string SId="";
        public static string TId="";

        private void loginBtn_Click(object sender, EventArgs e)
        {
            email = customTextBox1.Texts;

            Connection.OpenConection();

            SqlCommand sqlCmdUsers = new SqlCommand("SELECT Id FROM Users WHERE emailAddress=@emailAddress", Connection.sqlCon);
            

            sqlCmdUsers.Parameters.AddWithValue("@emailAddress", email);
            SqlDataReader users;
            users = sqlCmdUsers.ExecuteReader();

            while (users.Read())
            {
                SId = users["Id"].ToString();
            }
            Connection.CloseConnection();

            if (SId == "")
            {
                Connection.OpenConection();
                SqlCommand sqlCmdTeachers = new SqlCommand("SELECT Id FROM Teachers WHERE emailAddress=@emailAddress", Connection.sqlCon);
                sqlCmdTeachers.Parameters.AddWithValue("@emailAddress", email);
                SqlDataReader Teachers;
                Teachers = sqlCmdTeachers.ExecuteReader();

                while (Teachers.Read())
                {
                    TId = Teachers["Id"].ToString();
                }

                Connection.CloseConnection();
            }

            try
            {
                if (customTextBox1.Texts == "exmple@gmail.com")
                {
                    label9.Visible = true;
                }
                else if (SId == "" && TId == "")
                {
                    MessageBox.Show("Users not Found");
                }
                else
                {
                    string from, pass, messagebody;
                    Random rand = new Random();
                    randomcode = (rand.Next(999999)).ToString();
                    MailMessage message = new MailMessage();
                    to = (customTextBox1.Texts).ToString();
                    from = "myproject7259@gmail.com";
                    pass = "Project00.";
                    messagebody = $"Your Reset Code is {randomcode}";
                    message.To.Add(to);
                    message.From = new MailAddress(from);
                    message.Body = messagebody;
                    message.Subject = "Password Reset Code";
                    SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                    smtp.EnableSsl = true;
                    smtp.Port = 587;
                    smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtp.Credentials = new NetworkCredential(from, pass);
                    try
                    {
                        smtp.Send(message);
                        MessageBox.Show("Code Successfully Send");

                        this.Hide();
                        ForgetPass1 forgetPass1 = new ForgetPass1();
                        forgetPass1.ShowDialog();
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
                
            }
            catch (Exception ex)
            {
                if (customTextBox1.Texts == "exmple@gmail.com")
                {
                    label9.Visible = true;

                }
            }      
        }

        private void customTextBox1__TextChanged(object sender, EventArgs e)
        {
            if (label9.Visible == true)
            {
                label9.Visible = false;
            }
        }

        private void customTextBox1_Enter(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "exmple@gmail.com")
            {
                customTextBox1.Texts = "";
                customTextBox1.ForeColor = Color.Black;
            }
        }

        private void customTextBox1_Leave(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "")
            {
                customTextBox1.Texts = "exmple@gmail.com";
                customTextBox1.ForeColor = Color.DimGray;
            }

            if (customTextBox1.Texts != "exmple@gmail.com")
            {
                if (Regex.IsMatch(customTextBox1.Texts, pattern) == false)
                {
                    customTextBox1.Focus();
                    MessageBox.Show("Email Address is not valide", "All information is required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
