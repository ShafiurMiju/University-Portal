﻿using DAL;
using DAL.Entities;
using DAL.Interface;
using DAL.Tables;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class AddCourse : Form
    {
        public static int a;
        public AddCourse()
        {
            InitializeComponent();
            loadComboBox();
            SIIncrement();
            customTextBox2.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;
        }

        public void loadComboBox()
        {
            comboBox("SELECT * FROM Program", "pId", "pName", comboBox8);
            comboBox("SELECT * FROM CourseName", "cId", "cName", comboBox12);
        }

        //function to auto increment id 
        public void SIIncrement()
        {
            SqlDataAdapter sqladptr = new SqlDataAdapter("SELECT SI FROM CourseReg", Connection.sqlCon);
            Connection.OpenConection();
            DataTable dt = new DataTable();
            sqladptr.Fill(dt);

            if (dt.Rows.Count < 1)
            {
                customTextBox2.Texts = "1";
                customTextBox2.ForeColor = Color.Black;
            }
            else
            {
                SqlCommand sqladptr1 = new SqlCommand("SELECT MAX(SI) FROM CourseReg", Connection.sqlCon);
                
                int a = Convert.ToInt32(sqladptr1.ExecuteScalar());
                Connection.OpenConection();
                a = a + 1;
                customTextBox2.Texts = a.ToString();
                customTextBox2.ForeColor = Color.Black;
            }

            

        }

        //function for a comboBox to select data from database table
        public void comboBox(string q, string tc1, string tc2, ComboBox combobox)
        {
            SqlCommand sqlcom = new SqlCommand(q, Connection.sqlCon);

            Connection.OpenConection();

            SqlDataAdapter sqldpt = new SqlDataAdapter(sqlcom);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);

            combobox.ValueMember = tc1;
            combobox.DisplayMember = tc2;
            combobox.DataSource = dt;

            Connection.OpenConection();
        }

        //function for a dependent comboBox to select data from database table
        public void dComboBox(string q, string tc1, string tc2, string dtc1, ComboBox combobox, ComboBox dcombobox)
        {
            if (dcombobox.SelectedValue.ToString() != null)
            {
                SqlCommand sqlcom = new SqlCommand(q, Connection.sqlCon);
                Connection.OpenConection();
                sqlcom.Parameters.AddWithValue(dtc1, dcombobox.SelectedValue.ToString());
                SqlDataAdapter sqldpt = new SqlDataAdapter(sqlcom);

                DataTable dt = new DataTable();
                sqldpt.Fill(dt);

                combobox.ValueMember = tc1;
                combobox.DisplayMember = tc2;
                combobox.DataSource = dt;

                Connection.CloseConnection();
            }
        }

        //function to reset textBox and comboBox after insert a student 
        public void resertInsert()
        {
            loadComboBox();
            comboBox1.Text = "";
        }

        Info info = new Info();

        private void loginBtn_Click(object sender, EventArgs e)
        {
            if (comboBox8.Text == "AT FIRST SELECT DEPARTMENT"
                || comboBox12.Text == "SELECT ONE")
            {
                MessageBox.Show("Not Successful");
            }
            else if (customTextBox2.ForeColor == Color.Black
                && comboBox8.ForeColor == Color.Black
                && comboBox12.ForeColor == Color.Black
                && comboBox1.ForeColor == Color.Black)
            {
                try
                {
                    info.SI = Convert.ToInt32(customTextBox2.Texts);
                    info.CourseName=comboBox12.Text.Trim();
                    info.Section = comboBox1.Text.Trim();
                    info.Faculty = comboBox8.Text.Trim();

                    new Class1().infoTables.Insert(info);

                   
                    MessageBox.Show("Successful");
                    SIIncrement();
                    resertInsert();
                    //tableShow();
                    dataGridView1.DataSource = new Class1().infoTables.Get();
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Something Wrong");
                }
            }
            else
            {
                MessageBox.Show("Blank Field Must Fill Up");
            }
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            dComboBox("SELECT * FROM CourseName WHERE pId=@pId", "cId", "cName", "pId", comboBox12, comboBox8);
            if (comboBox8.Text == " SELECT ONE")
            {
                comboBox8.ForeColor = Color.DimGray;
            }
            else
                comboBox8.ForeColor = Color.Black;
        }

        private void comboBox12_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox12.Text == " AT FIRST SELECT DEPARTMENT")
            {
                comboBox12.ForeColor = Color.DimGray;
            }
            else
                comboBox12.ForeColor = Color.Black;
        }

        private void customTextBox2__TextChanged(object sender, EventArgs e)
        {

        }

        private void customTextBox2_Enter(object sender, EventArgs e)
        {
            MessageBox.Show("You can not change this field");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.ForeColor = Color.Black;
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            comboBox1.ForeColor = Color.Black;

        }

        /*public void tableShow()
        {
            Connection.OpenConection();

            SqlDataAdapter sqldpt = new SqlDataAdapter("SELECT * FROM CourseReg", Connection.sqlCon);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            dataGridView1.DataSource = dt;
            Connection.CloseConnection();
        }*/

        private void AddCourse_Load(object sender, EventArgs e)
        {
            //tableShow();
            dataGridView1.DataSource = new Class1().infoTables.Get();
        }

        public void search(DataGridView d, string q)
        {
            Connection.OpenConection();

            SqlDataAdapter sqldpt = new SqlDataAdapter(q, Connection.sqlCon);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            d.DataSource = dt;
            Connection.CloseConnection();
        }

        private void customTextBox1__TextChanged(object sender, EventArgs e)
        {
            search(dataGridView1, "SELECT * FROM CourseReg WHERE CourseName LIKE '" + customTextBox1.Texts + "%'");
            if (customTextBox1.Texts == "" || customTextBox1.Texts == "Search Here")
            {
                //tableShow();
                dataGridView1.DataSource = new Class1().infoTables.Get();
            }
        }

        private void customTextBox1_Enter(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "Search Here")
            {
                customTextBox1.Texts = "";
                customTextBox1.ForeColor = Color.Black;
            }
        }

        private void customTextBox1_Leave(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "")
            {
                customTextBox1.Texts = "Search Here";
                customTextBox1.ForeColor = Color.DimGray;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (customTextBox2.ForeColor == Color.Black
               && comboBox1.ForeColor == Color.Black
               && comboBox8.ForeColor == Color.Black
               && comboBox12.ForeColor == Color.Black)
            {
                try
                {
                    info.SI = int.Parse(customTextBox2.Texts);
                    info.CourseName = comboBox12.Text.Trim();
                    info.Section = comboBox1.Text.Trim();
                    info.Faculty = comboBox8.Text.Trim();

                    new Class1().infoTables.Update(info);
                    MessageBox.Show("Successful");

                    button1.Enabled = false;
                    button2.Enabled = false;
                    SIIncrement();
                    resertInsert();
                    dataGridView1.DataSource = new Class1().infoTables.Get();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Field Must Fill Up");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                info.SI = int.Parse(customTextBox2.Texts);

                new Class1().infoTables.Delete(info);

                MessageBox.Show("Successful");

                button1.Enabled = false;
                button2.Enabled = false;
                SIIncrement();
                resertInsert();
                dataGridView1.DataSource = new Class1().infoTables.Get();               
            }
            catch (Exception ex)
            {
                MessageBox.Show("fail");
            }
        }

        

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                customTextBox2.Texts = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                comboBox12.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                comboBox8.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                comboBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();

                customTextBox2.ForeColor = Color.Black;
                comboBox1.ForeColor = Color.Black;
                comboBox8.ForeColor = Color.Black;
                comboBox12.ForeColor = Color.Black;

                button1.Enabled = true;
                button2.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
