﻿
namespace projectDemo
{
    partial class RemoveStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RemoveStudent));
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.customTextBox1 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.loginBtn = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel138 = new System.Windows.Forms.Panel();
            this.panel139 = new System.Windows.Forms.Panel();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.panel140 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.panel141 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.panel142 = new System.Windows.Forms.Panel();
            this.panel143 = new System.Windows.Forms.Panel();
            this.panel132 = new System.Windows.Forms.Panel();
            this.panel133 = new System.Windows.Forms.Panel();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.panel134 = new System.Windows.Forms.Panel();
            this.label36 = new System.Windows.Forms.Label();
            this.panel135 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.panel136 = new System.Windows.Forms.Panel();
            this.panel137 = new System.Windows.Forms.Panel();
            this.panel125 = new System.Windows.Forms.Panel();
            this.panel126 = new System.Windows.Forms.Panel();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.panel127 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.panel128 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.panel129 = new System.Windows.Forms.Panel();
            this.panel130 = new System.Windows.Forms.Panel();
            this.panel119 = new System.Windows.Forms.Panel();
            this.panel120 = new System.Windows.Forms.Panel();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.panel121 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.panel122 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.panel123 = new System.Windows.Forms.Panel();
            this.panel124 = new System.Windows.Forms.Panel();
            this.panel114 = new System.Windows.Forms.Panel();
            this.panel115 = new System.Windows.Forms.Panel();
            this.customTextBox6 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.panel116 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.panel117 = new System.Windows.Forms.Panel();
            this.panel118 = new System.Windows.Forms.Panel();
            this.panel109 = new System.Windows.Forms.Panel();
            this.panel110 = new System.Windows.Forms.Panel();
            this.customTextBox5 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.panel111 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.panel112 = new System.Windows.Forms.Panel();
            this.panel113 = new System.Windows.Forms.Panel();
            this.panel99 = new System.Windows.Forms.Panel();
            this.panel100 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel101 = new System.Windows.Forms.Panel();
            this.panel102 = new System.Windows.Forms.Panel();
            this.panel103 = new System.Windows.Forms.Panel();
            this.panel104 = new System.Windows.Forms.Panel();
            this.panel105 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.panel106 = new System.Windows.Forms.Panel();
            this.panel107 = new System.Windows.Forms.Panel();
            this.panel90 = new System.Windows.Forms.Panel();
            this.panel91 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel98 = new System.Windows.Forms.Panel();
            this.panel97 = new System.Windows.Forms.Panel();
            this.panel96 = new System.Windows.Forms.Panel();
            this.panel95 = new System.Windows.Forms.Panel();
            this.panel92 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.panel93 = new System.Windows.Forms.Panel();
            this.panel94 = new System.Windows.Forms.Panel();
            this.panel82 = new System.Windows.Forms.Panel();
            this.panel83 = new System.Windows.Forms.Panel();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.panel84 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.panel85 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.panel86 = new System.Windows.Forms.Panel();
            this.panel87 = new System.Windows.Forms.Panel();
            this.panel76 = new System.Windows.Forms.Panel();
            this.panel77 = new System.Windows.Forms.Panel();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.panel78 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel79 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.panel80 = new System.Windows.Forms.Panel();
            this.panel81 = new System.Windows.Forms.Panel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.panel55 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel56 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel57 = new System.Windows.Forms.Panel();
            this.panel75 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.panel44 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel45 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.panel38 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel39 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel63 = new System.Windows.Forms.Panel();
            this.panel64 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel65 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel66 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.panel67 = new System.Windows.Forms.Panel();
            this.panel68 = new System.Windows.Forms.Panel();
            this.panel69 = new System.Windows.Forms.Panel();
            this.panel70 = new System.Windows.Forms.Panel();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.panel71 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.panel72 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.panel73 = new System.Windows.Forms.Panel();
            this.panel74 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.panel88 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel49 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel108 = new System.Windows.Forms.Panel();
            this.panel89 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.customTextBox4 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.program = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.customTextBox3 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.credit = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.customTextBox2 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.cgpa = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel131 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel151 = new System.Windows.Forms.Panel();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel138.SuspendLayout();
            this.panel139.SuspendLayout();
            this.panel141.SuspendLayout();
            this.panel132.SuspendLayout();
            this.panel133.SuspendLayout();
            this.panel135.SuspendLayout();
            this.panel125.SuspendLayout();
            this.panel126.SuspendLayout();
            this.panel128.SuspendLayout();
            this.panel119.SuspendLayout();
            this.panel120.SuspendLayout();
            this.panel122.SuspendLayout();
            this.panel114.SuspendLayout();
            this.panel115.SuspendLayout();
            this.panel116.SuspendLayout();
            this.panel109.SuspendLayout();
            this.panel110.SuspendLayout();
            this.panel111.SuspendLayout();
            this.panel99.SuspendLayout();
            this.panel100.SuspendLayout();
            this.panel105.SuspendLayout();
            this.panel90.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel92.SuspendLayout();
            this.panel82.SuspendLayout();
            this.panel83.SuspendLayout();
            this.panel85.SuspendLayout();
            this.panel76.SuspendLayout();
            this.panel77.SuspendLayout();
            this.panel79.SuspendLayout();
            this.panel53.SuspendLayout();
            this.panel54.SuspendLayout();
            this.panel56.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel63.SuspendLayout();
            this.panel64.SuspendLayout();
            this.panel66.SuspendLayout();
            this.panel69.SuspendLayout();
            this.panel70.SuspendLayout();
            this.panel72.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel131.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(834, 10);
            this.panel5.TabIndex = 5;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(824, 10);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 1045);
            this.panel4.TabIndex = 9;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 10);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 1045);
            this.panel3.TabIndex = 8;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(132)))), ((int)(((byte)(250)))));
            this.panel7.Controls.Add(this.customTextBox1);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(10, 10);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(814, 66);
            this.panel7.TabIndex = 10;
            // 
            // customTextBox1
            // 
            this.customTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.customTextBox1.BackColor = System.Drawing.Color.White;
            this.customTextBox1.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.customTextBox1.BorderFocusColor = System.Drawing.Color.Navy;
            this.customTextBox1.BorderSize = 1;
            this.customTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customTextBox1.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox1.Location = new System.Drawing.Point(516, 16);
            this.customTextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox1.Multiline = false;
            this.customTextBox1.Name = "customTextBox1";
            this.customTextBox1.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox1.PasswordChar = false;
            this.customTextBox1.Size = new System.Drawing.Size(291, 35);
            this.customTextBox1.TabIndex = 0;
            this.customTextBox1.Texts = "Search Here";
            this.customTextBox1.UnderlinedStyle = false;
            this.customTextBox1._TextChanged += new System.EventHandler(this.customTextBox1__TextChanged);
            this.customTextBox1.Enter += new System.EventHandler(this.customTextBox1_Enter);
            this.customTextBox1.Leave += new System.EventHandler(this.customTextBox1_Leave);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView1.Location = new System.Drawing.Point(10, 76);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(814, 64);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(10, 986);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(814, 69);
            this.panel1.TabIndex = 12;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.button1);
            this.panel8.Controls.Add(this.loginBtn);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(238, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(333, 69);
            this.panel8.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(127)))), ((int)(((byte)(175)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Dock = System.Windows.Forms.DockStyle.Left;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(79)))), ((int)(((byte)(159)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(79)))), ((int)(((byte)(159)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 69);
            this.button1.TabIndex = 7;
            this.button1.Text = "DELETE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // loginBtn
            // 
            this.loginBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(127)))), ((int)(((byte)(175)))));
            this.loginBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginBtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.loginBtn.FlatAppearance.BorderSize = 0;
            this.loginBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(79)))), ((int)(((byte)(159)))));
            this.loginBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(79)))), ((int)(((byte)(159)))));
            this.loginBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loginBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginBtn.ForeColor = System.Drawing.Color.White;
            this.loginBtn.Location = new System.Drawing.Point(133, 0);
            this.loginBtn.Name = "loginBtn";
            this.loginBtn.Size = new System.Drawing.Size(200, 69);
            this.loginBtn.TabIndex = 0;
            this.loginBtn.Text = "UPDATE";
            this.loginBtn.UseVisualStyleBackColor = false;
            this.loginBtn.Click += new System.EventHandler(this.loginBtn_Click);
            // 
            // panel6
            // 
            this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel6.Location = new System.Drawing.Point(571, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(243, 69);
            this.panel6.TabIndex = 9;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(238, 69);
            this.panel2.TabIndex = 8;
            // 
            // panel9
            // 
            this.panel9.AutoSize = true;
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(10, 140);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(814, 846);
            this.panel9.TabIndex = 13;
            // 
            // panel10
            // 
            this.panel10.AutoScroll = true;
            this.panel10.Controls.Add(this.panel138);
            this.panel10.Controls.Add(this.panel132);
            this.panel10.Controls.Add(this.panel125);
            this.panel10.Controls.Add(this.panel119);
            this.panel10.Controls.Add(this.panel114);
            this.panel10.Controls.Add(this.panel109);
            this.panel10.Controls.Add(this.panel99);
            this.panel10.Controls.Add(this.panel90);
            this.panel10.Controls.Add(this.panel82);
            this.panel10.Controls.Add(this.panel76);
            this.panel10.Controls.Add(this.panel53);
            this.panel10.Controls.Add(this.panel42);
            this.panel10.Controls.Add(this.panel36);
            this.panel10.Controls.Add(this.panel63);
            this.panel10.Controls.Add(this.panel69);
            this.panel10.Controls.Add(this.panel47);
            this.panel10.Controls.Add(this.panel31);
            this.panel10.Controls.Add(this.panel26);
            this.panel10.Controls.Add(this.panel21);
            this.panel10.Controls.Add(this.panel16);
            this.panel10.Controls.Add(this.panel131);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(814, 846);
            this.panel10.TabIndex = 17;
            // 
            // panel138
            // 
            this.panel138.Controls.Add(this.panel139);
            this.panel138.Controls.Add(this.panel141);
            this.panel138.Controls.Add(this.panel143);
            this.panel138.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel138.Location = new System.Drawing.Point(0, 811);
            this.panel138.Name = "panel138";
            this.panel138.Size = new System.Drawing.Size(814, 35);
            this.panel138.TabIndex = 54;
            // 
            // panel139
            // 
            this.panel139.Controls.Add(this.comboBox12);
            this.panel139.Controls.Add(this.panel140);
            this.panel139.Controls.Add(this.label38);
            this.panel139.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel139.Location = new System.Drawing.Point(120, 0);
            this.panel139.Name = "panel139";
            this.panel139.Size = new System.Drawing.Size(694, 34);
            this.panel139.TabIndex = 5;
            // 
            // comboBox12
            // 
            this.comboBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox12.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox12.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(0, 3);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(694, 30);
            this.comboBox12.TabIndex = 0;
            this.comboBox12.SelectedIndexChanged += new System.EventHandler(this.comboBox12_SelectedIndexChanged);
            this.comboBox12.Enter += new System.EventHandler(this.comboBox12_Enter);
            // 
            // panel140
            // 
            this.panel140.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel140.Location = new System.Drawing.Point(0, 0);
            this.panel140.Name = "panel140";
            this.panel140.Size = new System.Drawing.Size(694, 3);
            this.panel140.TabIndex = 4;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = System.Windows.Forms.DockStyle.Left;
            this.label38.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label38.Location = new System.Drawing.Point(0, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(0, 23);
            this.label38.TabIndex = 3;
            // 
            // panel141
            // 
            this.panel141.Controls.Add(this.label39);
            this.panel141.Controls.Add(this.panel142);
            this.panel141.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel141.Location = new System.Drawing.Point(0, 0);
            this.panel141.Name = "panel141";
            this.panel141.Size = new System.Drawing.Size(120, 34);
            this.panel141.TabIndex = 4;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = System.Windows.Forms.DockStyle.Right;
            this.label39.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(24, 7);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(96, 23);
            this.label39.TabIndex = 9;
            this.label39.Text = "Blood Group : ";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel142
            // 
            this.panel142.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel142.Location = new System.Drawing.Point(0, 0);
            this.panel142.Name = "panel142";
            this.panel142.Size = new System.Drawing.Size(120, 7);
            this.panel142.TabIndex = 3;
            // 
            // panel143
            // 
            this.panel143.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel143.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel143.Location = new System.Drawing.Point(0, 34);
            this.panel143.Name = "panel143";
            this.panel143.Size = new System.Drawing.Size(814, 1);
            this.panel143.TabIndex = 1;
            // 
            // panel132
            // 
            this.panel132.Controls.Add(this.panel133);
            this.panel132.Controls.Add(this.panel135);
            this.panel132.Controls.Add(this.panel137);
            this.panel132.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel132.Location = new System.Drawing.Point(0, 776);
            this.panel132.Name = "panel132";
            this.panel132.Size = new System.Drawing.Size(814, 35);
            this.panel132.TabIndex = 53;
            // 
            // panel133
            // 
            this.panel133.Controls.Add(this.comboBox11);
            this.panel133.Controls.Add(this.panel134);
            this.panel133.Controls.Add(this.label36);
            this.panel133.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel133.Location = new System.Drawing.Point(120, 0);
            this.panel133.Name = "panel133";
            this.panel133.Size = new System.Drawing.Size(694, 34);
            this.panel133.TabIndex = 5;
            // 
            // comboBox11
            // 
            this.comboBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox11.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox11.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Location = new System.Drawing.Point(0, 3);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(694, 30);
            this.comboBox11.TabIndex = 0;
            this.comboBox11.SelectedIndexChanged += new System.EventHandler(this.comboBox11_SelectedIndexChanged);
            this.comboBox11.Enter += new System.EventHandler(this.comboBox11_Enter);
            // 
            // panel134
            // 
            this.panel134.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel134.Location = new System.Drawing.Point(0, 0);
            this.panel134.Name = "panel134";
            this.panel134.Size = new System.Drawing.Size(694, 3);
            this.panel134.TabIndex = 4;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Left;
            this.label36.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label36.Location = new System.Drawing.Point(0, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(0, 23);
            this.label36.TabIndex = 3;
            // 
            // panel135
            // 
            this.panel135.Controls.Add(this.label37);
            this.panel135.Controls.Add(this.panel136);
            this.panel135.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel135.Location = new System.Drawing.Point(0, 0);
            this.panel135.Name = "panel135";
            this.panel135.Size = new System.Drawing.Size(120, 34);
            this.panel135.TabIndex = 4;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = System.Windows.Forms.DockStyle.Right;
            this.label37.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(8, 7);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(112, 23);
            this.label37.TabIndex = 9;
            this.label37.Text = "Marital Status : ";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel136
            // 
            this.panel136.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel136.Location = new System.Drawing.Point(0, 0);
            this.panel136.Name = "panel136";
            this.panel136.Size = new System.Drawing.Size(120, 7);
            this.panel136.TabIndex = 3;
            // 
            // panel137
            // 
            this.panel137.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel137.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel137.Location = new System.Drawing.Point(0, 34);
            this.panel137.Name = "panel137";
            this.panel137.Size = new System.Drawing.Size(814, 1);
            this.panel137.TabIndex = 1;
            // 
            // panel125
            // 
            this.panel125.Controls.Add(this.panel126);
            this.panel125.Controls.Add(this.panel128);
            this.panel125.Controls.Add(this.panel130);
            this.panel125.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel125.Location = new System.Drawing.Point(0, 741);
            this.panel125.Name = "panel125";
            this.panel125.Size = new System.Drawing.Size(814, 35);
            this.panel125.TabIndex = 52;
            // 
            // panel126
            // 
            this.panel126.Controls.Add(this.comboBox10);
            this.panel126.Controls.Add(this.panel127);
            this.panel126.Controls.Add(this.label34);
            this.panel126.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel126.Location = new System.Drawing.Point(120, 0);
            this.panel126.Name = "panel126";
            this.panel126.Size = new System.Drawing.Size(694, 34);
            this.panel126.TabIndex = 5;
            // 
            // comboBox10
            // 
            this.comboBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox10.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox10.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(0, 3);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(694, 30);
            this.comboBox10.TabIndex = 0;
            this.comboBox10.SelectedIndexChanged += new System.EventHandler(this.comboBox10_SelectedIndexChanged);
            this.comboBox10.Enter += new System.EventHandler(this.comboBox10_Enter);
            // 
            // panel127
            // 
            this.panel127.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel127.Location = new System.Drawing.Point(0, 0);
            this.panel127.Name = "panel127";
            this.panel127.Size = new System.Drawing.Size(694, 3);
            this.panel127.TabIndex = 4;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Left;
            this.label34.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label34.Location = new System.Drawing.Point(0, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(0, 23);
            this.label34.TabIndex = 3;
            // 
            // panel128
            // 
            this.panel128.Controls.Add(this.label35);
            this.panel128.Controls.Add(this.panel129);
            this.panel128.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel128.Location = new System.Drawing.Point(0, 0);
            this.panel128.Name = "panel128";
            this.panel128.Size = new System.Drawing.Size(120, 34);
            this.panel128.TabIndex = 4;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Right;
            this.label35.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(48, 7);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(72, 23);
            this.label35.TabIndex = 9;
            this.label35.Text = "Religion : ";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel129
            // 
            this.panel129.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel129.Location = new System.Drawing.Point(0, 0);
            this.panel129.Name = "panel129";
            this.panel129.Size = new System.Drawing.Size(120, 7);
            this.panel129.TabIndex = 3;
            // 
            // panel130
            // 
            this.panel130.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel130.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel130.Location = new System.Drawing.Point(0, 34);
            this.panel130.Name = "panel130";
            this.panel130.Size = new System.Drawing.Size(814, 1);
            this.panel130.TabIndex = 1;
            // 
            // panel119
            // 
            this.panel119.Controls.Add(this.panel120);
            this.panel119.Controls.Add(this.panel122);
            this.panel119.Controls.Add(this.panel124);
            this.panel119.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel119.Location = new System.Drawing.Point(0, 706);
            this.panel119.Name = "panel119";
            this.panel119.Size = new System.Drawing.Size(814, 35);
            this.panel119.TabIndex = 51;
            // 
            // panel120
            // 
            this.panel120.Controls.Add(this.comboBox9);
            this.panel120.Controls.Add(this.panel121);
            this.panel120.Controls.Add(this.label32);
            this.panel120.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel120.Location = new System.Drawing.Point(120, 0);
            this.panel120.Name = "panel120";
            this.panel120.Size = new System.Drawing.Size(694, 34);
            this.panel120.TabIndex = 5;
            // 
            // comboBox9
            // 
            this.comboBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox9.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox9.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(0, 3);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(694, 30);
            this.comboBox9.TabIndex = 0;
            this.comboBox9.SelectedIndexChanged += new System.EventHandler(this.comboBox9_SelectedIndexChanged);
            this.comboBox9.Enter += new System.EventHandler(this.comboBox9_Enter);
            // 
            // panel121
            // 
            this.panel121.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel121.Location = new System.Drawing.Point(0, 0);
            this.panel121.Name = "panel121";
            this.panel121.Size = new System.Drawing.Size(694, 3);
            this.panel121.TabIndex = 4;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Left;
            this.label32.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label32.Location = new System.Drawing.Point(0, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(0, 23);
            this.label32.TabIndex = 3;
            // 
            // panel122
            // 
            this.panel122.Controls.Add(this.label33);
            this.panel122.Controls.Add(this.panel123);
            this.panel122.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel122.Location = new System.Drawing.Point(0, 0);
            this.panel122.Name = "panel122";
            this.panel122.Size = new System.Drawing.Size(120, 34);
            this.panel122.TabIndex = 4;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Right;
            this.label33.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(31, 7);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(89, 23);
            this.label33.TabIndex = 9;
            this.label33.Text = "Nationality : ";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel123
            // 
            this.panel123.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel123.Location = new System.Drawing.Point(0, 0);
            this.panel123.Name = "panel123";
            this.panel123.Size = new System.Drawing.Size(120, 7);
            this.panel123.TabIndex = 3;
            // 
            // panel124
            // 
            this.panel124.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel124.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel124.Location = new System.Drawing.Point(0, 34);
            this.panel124.Name = "panel124";
            this.panel124.Size = new System.Drawing.Size(814, 1);
            this.panel124.TabIndex = 1;
            // 
            // panel114
            // 
            this.panel114.Controls.Add(this.panel115);
            this.panel114.Controls.Add(this.panel116);
            this.panel114.Controls.Add(this.panel118);
            this.panel114.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel114.Location = new System.Drawing.Point(0, 671);
            this.panel114.Name = "panel114";
            this.panel114.Size = new System.Drawing.Size(814, 35);
            this.panel114.TabIndex = 50;
            // 
            // panel115
            // 
            this.panel115.Controls.Add(this.customTextBox6);
            this.panel115.Controls.Add(this.label30);
            this.panel115.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel115.Location = new System.Drawing.Point(120, 0);
            this.panel115.Name = "panel115";
            this.panel115.Size = new System.Drawing.Size(694, 34);
            this.panel115.TabIndex = 5;
            // 
            // customTextBox6
            // 
            this.customTextBox6.BackColor = System.Drawing.Color.White;
            this.customTextBox6.BorderColor = System.Drawing.Color.White;
            this.customTextBox6.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox6.BorderSize = 0;
            this.customTextBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox6.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox6.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox6.Location = new System.Drawing.Point(0, 0);
            this.customTextBox6.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox6.Multiline = false;
            this.customTextBox6.Name = "customTextBox6";
            this.customTextBox6.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox6.PasswordChar = false;
            this.customTextBox6.Size = new System.Drawing.Size(694, 38);
            this.customTextBox6.TabIndex = 0;
            this.customTextBox6.Tag = "1";
            this.customTextBox6.Texts = "Enter Email Address";
            this.customTextBox6.UnderlinedStyle = false;
            this.customTextBox6.Enter += new System.EventHandler(this.customTextBox6_Enter);
            this.customTextBox6.Leave += new System.EventHandler(this.customTextBox6_Leave);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Left;
            this.label30.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label30.Location = new System.Drawing.Point(0, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(0, 23);
            this.label30.TabIndex = 3;
            // 
            // panel116
            // 
            this.panel116.Controls.Add(this.label31);
            this.panel116.Controls.Add(this.panel117);
            this.panel116.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel116.Location = new System.Drawing.Point(0, 0);
            this.panel116.Name = "panel116";
            this.panel116.Size = new System.Drawing.Size(120, 34);
            this.panel116.TabIndex = 4;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Right;
            this.label31.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(9, 7);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(111, 23);
            this.label31.TabIndex = 9;
            this.label31.Text = "Email Address : ";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel117
            // 
            this.panel117.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel117.Location = new System.Drawing.Point(0, 0);
            this.panel117.Name = "panel117";
            this.panel117.Size = new System.Drawing.Size(120, 7);
            this.panel117.TabIndex = 3;
            // 
            // panel118
            // 
            this.panel118.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel118.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel118.Location = new System.Drawing.Point(0, 34);
            this.panel118.Name = "panel118";
            this.panel118.Size = new System.Drawing.Size(814, 1);
            this.panel118.TabIndex = 1;
            // 
            // panel109
            // 
            this.panel109.Controls.Add(this.panel110);
            this.panel109.Controls.Add(this.panel111);
            this.panel109.Controls.Add(this.panel113);
            this.panel109.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel109.Location = new System.Drawing.Point(0, 636);
            this.panel109.Name = "panel109";
            this.panel109.Size = new System.Drawing.Size(814, 35);
            this.panel109.TabIndex = 49;
            // 
            // panel110
            // 
            this.panel110.Controls.Add(this.customTextBox5);
            this.panel110.Controls.Add(this.label28);
            this.panel110.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel110.Location = new System.Drawing.Point(120, 0);
            this.panel110.Name = "panel110";
            this.panel110.Size = new System.Drawing.Size(694, 34);
            this.panel110.TabIndex = 5;
            // 
            // customTextBox5
            // 
            this.customTextBox5.BackColor = System.Drawing.Color.White;
            this.customTextBox5.BorderColor = System.Drawing.Color.White;
            this.customTextBox5.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox5.BorderSize = 0;
            this.customTextBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox5.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox5.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox5.Location = new System.Drawing.Point(0, 0);
            this.customTextBox5.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox5.Multiline = false;
            this.customTextBox5.Name = "customTextBox5";
            this.customTextBox5.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox5.PasswordChar = false;
            this.customTextBox5.Size = new System.Drawing.Size(694, 38);
            this.customTextBox5.TabIndex = 0;
            this.customTextBox5.Tag = "1";
            this.customTextBox5.Texts = "Enter Contact Number";
            this.customTextBox5.UnderlinedStyle = false;
            this.customTextBox5.Enter += new System.EventHandler(this.customTextBox5_Enter);
            this.customTextBox5.Leave += new System.EventHandler(this.customTextBox5_Leave);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Left;
            this.label28.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label28.Location = new System.Drawing.Point(0, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(0, 23);
            this.label28.TabIndex = 3;
            // 
            // panel111
            // 
            this.panel111.Controls.Add(this.label29);
            this.panel111.Controls.Add(this.panel112);
            this.panel111.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel111.Location = new System.Drawing.Point(0, 0);
            this.panel111.Name = "panel111";
            this.panel111.Size = new System.Drawing.Size(120, 34);
            this.panel111.TabIndex = 4;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Right;
            this.label29.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(-2, 7);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(122, 23);
            this.label29.TabIndex = 9;
            this.label29.Text = "Contact Number : ";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel112
            // 
            this.panel112.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel112.Location = new System.Drawing.Point(0, 0);
            this.panel112.Name = "panel112";
            this.panel112.Size = new System.Drawing.Size(120, 7);
            this.panel112.TabIndex = 3;
            // 
            // panel113
            // 
            this.panel113.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel113.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel113.Location = new System.Drawing.Point(0, 34);
            this.panel113.Name = "panel113";
            this.panel113.Size = new System.Drawing.Size(814, 1);
            this.panel113.TabIndex = 1;
            // 
            // panel99
            // 
            this.panel99.Controls.Add(this.panel100);
            this.panel99.Controls.Add(this.panel105);
            this.panel99.Controls.Add(this.panel107);
            this.panel99.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel99.Location = new System.Drawing.Point(0, 554);
            this.panel99.Name = "panel99";
            this.panel99.Size = new System.Drawing.Size(814, 82);
            this.panel99.TabIndex = 48;
            // 
            // panel100
            // 
            this.panel100.Controls.Add(this.textBox2);
            this.panel100.Controls.Add(this.panel101);
            this.panel100.Controls.Add(this.panel102);
            this.panel100.Controls.Add(this.panel103);
            this.panel100.Controls.Add(this.panel104);
            this.panel100.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel100.Location = new System.Drawing.Point(120, 0);
            this.panel100.Name = "panel100";
            this.panel100.Size = new System.Drawing.Size(694, 81);
            this.panel100.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.textBox2.ForeColor = System.Drawing.Color.DimGray;
            this.textBox2.Location = new System.Drawing.Point(7, 7);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(680, 67);
            this.textBox2.TabIndex = 8;
            this.textBox2.Text = "Enter Permanent Address";
            this.textBox2.Enter += new System.EventHandler(this.textBox2_Enter);
            this.textBox2.Leave += new System.EventHandler(this.textBox2_Leave);
            // 
            // panel101
            // 
            this.panel101.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel101.Location = new System.Drawing.Point(687, 7);
            this.panel101.Name = "panel101";
            this.panel101.Size = new System.Drawing.Size(7, 67);
            this.panel101.TabIndex = 7;
            // 
            // panel102
            // 
            this.panel102.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel102.Location = new System.Drawing.Point(0, 7);
            this.panel102.Name = "panel102";
            this.panel102.Size = new System.Drawing.Size(7, 67);
            this.panel102.TabIndex = 6;
            // 
            // panel103
            // 
            this.panel103.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel103.Location = new System.Drawing.Point(0, 74);
            this.panel103.Name = "panel103";
            this.panel103.Size = new System.Drawing.Size(694, 7);
            this.panel103.TabIndex = 5;
            // 
            // panel104
            // 
            this.panel104.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel104.Location = new System.Drawing.Point(0, 0);
            this.panel104.Name = "panel104";
            this.panel104.Size = new System.Drawing.Size(694, 7);
            this.panel104.TabIndex = 4;
            // 
            // panel105
            // 
            this.panel105.Controls.Add(this.label26);
            this.panel105.Controls.Add(this.panel106);
            this.panel105.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel105.Location = new System.Drawing.Point(0, 0);
            this.panel105.Name = "panel105";
            this.panel105.Size = new System.Drawing.Size(120, 81);
            this.panel105.TabIndex = 4;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Right;
            this.label26.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(-24, 30);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(144, 23);
            this.label26.TabIndex = 9;
            this.label26.Text = "Permanent Address : ";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel106
            // 
            this.panel106.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel106.Location = new System.Drawing.Point(0, 0);
            this.panel106.Name = "panel106";
            this.panel106.Size = new System.Drawing.Size(120, 30);
            this.panel106.TabIndex = 3;
            // 
            // panel107
            // 
            this.panel107.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel107.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel107.Location = new System.Drawing.Point(0, 81);
            this.panel107.Name = "panel107";
            this.panel107.Size = new System.Drawing.Size(814, 1);
            this.panel107.TabIndex = 1;
            // 
            // panel90
            // 
            this.panel90.Controls.Add(this.panel91);
            this.panel90.Controls.Add(this.panel92);
            this.panel90.Controls.Add(this.panel94);
            this.panel90.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel90.Location = new System.Drawing.Point(0, 472);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(814, 82);
            this.panel90.TabIndex = 47;
            // 
            // panel91
            // 
            this.panel91.Controls.Add(this.textBox1);
            this.panel91.Controls.Add(this.panel98);
            this.panel91.Controls.Add(this.panel97);
            this.panel91.Controls.Add(this.panel96);
            this.panel91.Controls.Add(this.panel95);
            this.panel91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel91.Location = new System.Drawing.Point(120, 0);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(694, 81);
            this.panel91.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.textBox1.ForeColor = System.Drawing.Color.DimGray;
            this.textBox1.Location = new System.Drawing.Point(7, 7);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(680, 67);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "Enter Present Address";
            this.textBox1.Enter += new System.EventHandler(this.textBox1_Enter);
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // panel98
            // 
            this.panel98.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel98.Location = new System.Drawing.Point(687, 7);
            this.panel98.Name = "panel98";
            this.panel98.Size = new System.Drawing.Size(7, 67);
            this.panel98.TabIndex = 7;
            // 
            // panel97
            // 
            this.panel97.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel97.Location = new System.Drawing.Point(0, 7);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(7, 67);
            this.panel97.TabIndex = 6;
            // 
            // panel96
            // 
            this.panel96.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel96.Location = new System.Drawing.Point(0, 74);
            this.panel96.Name = "panel96";
            this.panel96.Size = new System.Drawing.Size(694, 7);
            this.panel96.TabIndex = 5;
            // 
            // panel95
            // 
            this.panel95.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel95.Location = new System.Drawing.Point(0, 0);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(694, 7);
            this.panel95.TabIndex = 4;
            // 
            // panel92
            // 
            this.panel92.Controls.Add(this.label27);
            this.panel92.Controls.Add(this.panel93);
            this.panel92.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel92.Location = new System.Drawing.Point(0, 0);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(120, 81);
            this.panel92.TabIndex = 4;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Right;
            this.label27.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(-4, 30);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(124, 23);
            this.label27.TabIndex = 9;
            this.label27.Text = "Present Address : ";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel93
            // 
            this.panel93.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel93.Location = new System.Drawing.Point(0, 0);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(120, 30);
            this.panel93.TabIndex = 3;
            // 
            // panel94
            // 
            this.panel94.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel94.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel94.Location = new System.Drawing.Point(0, 81);
            this.panel94.Name = "panel94";
            this.panel94.Size = new System.Drawing.Size(814, 1);
            this.panel94.TabIndex = 1;
            // 
            // panel82
            // 
            this.panel82.Controls.Add(this.panel83);
            this.panel82.Controls.Add(this.panel85);
            this.panel82.Controls.Add(this.panel87);
            this.panel82.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel82.Location = new System.Drawing.Point(0, 437);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(814, 35);
            this.panel82.TabIndex = 46;
            // 
            // panel83
            // 
            this.panel83.Controls.Add(this.comboBox7);
            this.panel83.Controls.Add(this.panel84);
            this.panel83.Controls.Add(this.label24);
            this.panel83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel83.Location = new System.Drawing.Point(120, 0);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(694, 34);
            this.panel83.TabIndex = 5;
            // 
            // comboBox7
            // 
            this.comboBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox7.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox7.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(0, 3);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(694, 30);
            this.comboBox7.TabIndex = 0;
            // 
            // panel84
            // 
            this.panel84.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel84.Location = new System.Drawing.Point(0, 0);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(694, 3);
            this.panel84.TabIndex = 4;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Left;
            this.label24.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label24.Location = new System.Drawing.Point(0, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 23);
            this.label24.TabIndex = 3;
            // 
            // panel85
            // 
            this.panel85.Controls.Add(this.label25);
            this.panel85.Controls.Add(this.panel86);
            this.panel85.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel85.Location = new System.Drawing.Point(0, 0);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(120, 34);
            this.panel85.TabIndex = 4;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Right;
            this.label25.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(51, 7);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(69, 23);
            this.label25.TabIndex = 9;
            this.label25.Text = "Elective : ";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel86
            // 
            this.panel86.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel86.Location = new System.Drawing.Point(0, 0);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(120, 7);
            this.panel86.TabIndex = 3;
            // 
            // panel87
            // 
            this.panel87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel87.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel87.Location = new System.Drawing.Point(0, 34);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(814, 1);
            this.panel87.TabIndex = 1;
            // 
            // panel76
            // 
            this.panel76.Controls.Add(this.panel77);
            this.panel76.Controls.Add(this.panel79);
            this.panel76.Controls.Add(this.panel81);
            this.panel76.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel76.Location = new System.Drawing.Point(0, 402);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(814, 35);
            this.panel76.TabIndex = 45;
            // 
            // panel77
            // 
            this.panel77.Controls.Add(this.comboBox6);
            this.panel77.Controls.Add(this.panel78);
            this.panel77.Controls.Add(this.label22);
            this.panel77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel77.Location = new System.Drawing.Point(120, 0);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(694, 34);
            this.panel77.TabIndex = 5;
            // 
            // comboBox6
            // 
            this.comboBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox6.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox6.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(0, 3);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(694, 30);
            this.comboBox6.TabIndex = 0;
            // 
            // panel78
            // 
            this.panel78.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel78.Location = new System.Drawing.Point(0, 0);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(694, 3);
            this.panel78.TabIndex = 4;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Left;
            this.label22.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label22.Location = new System.Drawing.Point(0, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(0, 23);
            this.label22.TabIndex = 3;
            // 
            // panel79
            // 
            this.panel79.Controls.Add(this.label23);
            this.panel79.Controls.Add(this.panel80);
            this.panel79.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel79.Location = new System.Drawing.Point(0, 0);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(120, 34);
            this.panel79.TabIndex = 4;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = System.Windows.Forms.DockStyle.Right;
            this.label23.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(63, 7);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(57, 23);
            this.label23.TabIndex = 9;
            this.label23.Text = "Minor : ";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel80
            // 
            this.panel80.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel80.Location = new System.Drawing.Point(0, 0);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(120, 7);
            this.panel80.TabIndex = 3;
            // 
            // panel81
            // 
            this.panel81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel81.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel81.Location = new System.Drawing.Point(0, 34);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(814, 1);
            this.panel81.TabIndex = 1;
            // 
            // panel53
            // 
            this.panel53.Controls.Add(this.panel54);
            this.panel53.Controls.Add(this.panel56);
            this.panel53.Controls.Add(this.panel75);
            this.panel53.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel53.Location = new System.Drawing.Point(0, 367);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(814, 35);
            this.panel53.TabIndex = 44;
            // 
            // panel54
            // 
            this.panel54.Controls.Add(this.comboBox5);
            this.panel54.Controls.Add(this.panel55);
            this.panel54.Controls.Add(this.label14);
            this.panel54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel54.Location = new System.Drawing.Point(120, 0);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(694, 34);
            this.panel54.TabIndex = 5;
            // 
            // comboBox5
            // 
            this.comboBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox5.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox5.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(0, 3);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(694, 30);
            this.comboBox5.TabIndex = 0;
            // 
            // panel55
            // 
            this.panel55.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel55.Location = new System.Drawing.Point(0, 0);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(694, 3);
            this.panel55.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Left;
            this.label14.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label14.Location = new System.Drawing.Point(0, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 23);
            this.label14.TabIndex = 3;
            // 
            // panel56
            // 
            this.panel56.Controls.Add(this.label15);
            this.panel56.Controls.Add(this.panel57);
            this.panel56.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel56.Location = new System.Drawing.Point(0, 0);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(120, 34);
            this.panel56.TabIndex = 4;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Right;
            this.label15.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(14, 7);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(106, 23);
            this.label15.TabIndex = 9;
            this.label15.Text = "Second Major : ";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel57
            // 
            this.panel57.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel57.Location = new System.Drawing.Point(0, 0);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(120, 7);
            this.panel57.TabIndex = 3;
            // 
            // panel75
            // 
            this.panel75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel75.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel75.Location = new System.Drawing.Point(0, 34);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(814, 1);
            this.panel75.TabIndex = 1;
            // 
            // panel42
            // 
            this.panel42.Controls.Add(this.panel43);
            this.panel42.Controls.Add(this.panel45);
            this.panel42.Controls.Add(this.panel52);
            this.panel42.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel42.Location = new System.Drawing.Point(0, 332);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(814, 35);
            this.panel42.TabIndex = 43;
            // 
            // panel43
            // 
            this.panel43.Controls.Add(this.comboBox4);
            this.panel43.Controls.Add(this.panel44);
            this.panel43.Controls.Add(this.label7);
            this.panel43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel43.Location = new System.Drawing.Point(120, 0);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(694, 34);
            this.panel43.TabIndex = 5;
            // 
            // comboBox4
            // 
            this.comboBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox4.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox4.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(0, 3);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(694, 30);
            this.comboBox4.TabIndex = 0;
            // 
            // panel44
            // 
            this.panel44.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel44.Location = new System.Drawing.Point(0, 0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(694, 3);
            this.panel44.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Left;
            this.label7.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 23);
            this.label7.TabIndex = 3;
            // 
            // panel45
            // 
            this.panel45.Controls.Add(this.label9);
            this.panel45.Controls.Add(this.panel46);
            this.panel45.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel45.Location = new System.Drawing.Point(0, 0);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(120, 34);
            this.panel45.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Right;
            this.label9.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(63, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 23);
            this.label9.TabIndex = 9;
            this.label9.Text = "Major : ";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel46
            // 
            this.panel46.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel46.Location = new System.Drawing.Point(0, 0);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(120, 7);
            this.panel46.TabIndex = 3;
            // 
            // panel52
            // 
            this.panel52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel52.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel52.Location = new System.Drawing.Point(0, 34);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(814, 1);
            this.panel52.TabIndex = 1;
            // 
            // panel36
            // 
            this.panel36.Controls.Add(this.panel37);
            this.panel36.Controls.Add(this.panel39);
            this.panel36.Controls.Add(this.panel41);
            this.panel36.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel36.Location = new System.Drawing.Point(0, 297);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(814, 35);
            this.panel36.TabIndex = 42;
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.comboBox2);
            this.panel37.Controls.Add(this.panel38);
            this.panel37.Controls.Add(this.label4);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel37.Location = new System.Drawing.Point(120, 0);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(694, 34);
            this.panel37.TabIndex = 5;
            // 
            // comboBox2
            // 
            this.comboBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox2.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox2.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(0, 3);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(694, 30);
            this.comboBox2.TabIndex = 0;
            // 
            // panel38
            // 
            this.panel38.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel38.Location = new System.Drawing.Point(0, 0);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(694, 3);
            this.panel38.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Left;
            this.label4.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 23);
            this.label4.TabIndex = 3;
            // 
            // panel39
            // 
            this.panel39.Controls.Add(this.label5);
            this.panel39.Controls.Add(this.panel40);
            this.panel39.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel39.Location = new System.Drawing.Point(0, 0);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(120, 34);
            this.panel39.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Right;
            this.label5.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(71, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 23);
            this.label5.TabIndex = 9;
            this.label5.Text = "Core : ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel40
            // 
            this.panel40.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel40.Location = new System.Drawing.Point(0, 0);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(120, 7);
            this.panel40.TabIndex = 3;
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel41.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel41.Location = new System.Drawing.Point(0, 34);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(814, 1);
            this.panel41.TabIndex = 1;
            // 
            // panel63
            // 
            this.panel63.Controls.Add(this.panel64);
            this.panel63.Controls.Add(this.panel66);
            this.panel63.Controls.Add(this.panel68);
            this.panel63.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel63.Location = new System.Drawing.Point(0, 262);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(814, 35);
            this.panel63.TabIndex = 41;
            // 
            // panel64
            // 
            this.panel64.Controls.Add(this.comboBox1);
            this.panel64.Controls.Add(this.panel65);
            this.panel64.Controls.Add(this.label18);
            this.panel64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel64.Location = new System.Drawing.Point(120, 0);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(694, 34);
            this.panel64.TabIndex = 5;
            // 
            // comboBox1
            // 
            this.comboBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox1.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(0, 3);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(694, 30);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.Enter += new System.EventHandler(this.comboBox1_Enter);
            // 
            // panel65
            // 
            this.panel65.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel65.Location = new System.Drawing.Point(0, 0);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(694, 3);
            this.panel65.TabIndex = 4;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Left;
            this.label18.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label18.Location = new System.Drawing.Point(0, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 23);
            this.label18.TabIndex = 3;
            // 
            // panel66
            // 
            this.panel66.Controls.Add(this.label19);
            this.panel66.Controls.Add(this.panel67);
            this.panel66.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel66.Location = new System.Drawing.Point(0, 0);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(120, 34);
            this.panel66.TabIndex = 4;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Right;
            this.label19.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(44, 7);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(76, 23);
            this.label19.TabIndex = 9;
            this.label19.Text = "Program : ";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel67
            // 
            this.panel67.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel67.Location = new System.Drawing.Point(0, 0);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(120, 7);
            this.panel67.TabIndex = 3;
            // 
            // panel68
            // 
            this.panel68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel68.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel68.Location = new System.Drawing.Point(0, 34);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(814, 1);
            this.panel68.TabIndex = 1;
            // 
            // panel69
            // 
            this.panel69.Controls.Add(this.panel70);
            this.panel69.Controls.Add(this.panel72);
            this.panel69.Controls.Add(this.panel74);
            this.panel69.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel69.Location = new System.Drawing.Point(0, 227);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(814, 35);
            this.panel69.TabIndex = 40;
            // 
            // panel70
            // 
            this.panel70.Controls.Add(this.comboBox3);
            this.panel70.Controls.Add(this.panel71);
            this.panel70.Controls.Add(this.label20);
            this.panel70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel70.Location = new System.Drawing.Point(120, 0);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(694, 34);
            this.panel70.TabIndex = 5;
            // 
            // comboBox3
            // 
            this.comboBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox3.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox3.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(0, 3);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(694, 30);
            this.comboBox3.TabIndex = 0;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            this.comboBox3.Enter += new System.EventHandler(this.comboBox3_Enter);
            // 
            // panel71
            // 
            this.panel71.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel71.Location = new System.Drawing.Point(0, 0);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(694, 3);
            this.panel71.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Left;
            this.label20.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label20.Location = new System.Drawing.Point(0, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(0, 23);
            this.label20.TabIndex = 3;
            // 
            // panel72
            // 
            this.panel72.Controls.Add(this.label21);
            this.panel72.Controls.Add(this.panel73);
            this.panel72.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel72.Location = new System.Drawing.Point(0, 0);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(120, 34);
            this.panel72.TabIndex = 4;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Right;
            this.label21.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(25, 7);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(95, 23);
            this.label21.TabIndex = 9;
            this.label21.Text = "Department : ";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel73
            // 
            this.panel73.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel73.Location = new System.Drawing.Point(0, 0);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(120, 7);
            this.panel73.TabIndex = 3;
            // 
            // panel74
            // 
            this.panel74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel74.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel74.Location = new System.Drawing.Point(0, 34);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(814, 1);
            this.panel74.TabIndex = 1;
            // 
            // panel47
            // 
            this.panel47.Controls.Add(this.panel48);
            this.panel47.Controls.Add(this.panel49);
            this.panel47.Controls.Add(this.panel51);
            this.panel47.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel47.Location = new System.Drawing.Point(0, 192);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(814, 35);
            this.panel47.TabIndex = 34;
            // 
            // panel48
            // 
            this.panel48.Controls.Add(this.comboBox8);
            this.panel48.Controls.Add(this.panel88);
            this.panel48.Controls.Add(this.label11);
            this.panel48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel48.Location = new System.Drawing.Point(120, 0);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(694, 34);
            this.panel48.TabIndex = 5;
            // 
            // comboBox8
            // 
            this.comboBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox8.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox8.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(0, 3);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(694, 30);
            this.comboBox8.TabIndex = 6;
            this.comboBox8.SelectedIndexChanged += new System.EventHandler(this.comboBox8_SelectedIndexChanged);
            this.comboBox8.Enter += new System.EventHandler(this.comboBox8_Enter);
            // 
            // panel88
            // 
            this.panel88.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel88.Location = new System.Drawing.Point(0, 0);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(694, 3);
            this.panel88.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Left;
            this.label11.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label11.Location = new System.Drawing.Point(0, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 23);
            this.label11.TabIndex = 3;
            // 
            // panel49
            // 
            this.panel49.Controls.Add(this.label13);
            this.panel49.Controls.Add(this.panel50);
            this.panel49.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel49.Location = new System.Drawing.Point(0, 0);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(120, 34);
            this.panel49.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Right;
            this.label13.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(77, 7);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 23);
            this.label13.TabIndex = 9;
            this.label13.Text = "Sex : ";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel50
            // 
            this.panel50.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel50.Location = new System.Drawing.Point(0, 0);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(120, 7);
            this.panel50.TabIndex = 3;
            // 
            // panel51
            // 
            this.panel51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel51.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel51.Location = new System.Drawing.Point(0, 34);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(814, 1);
            this.panel51.TabIndex = 1;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.panel32);
            this.panel31.Controls.Add(this.panel33);
            this.panel31.Controls.Add(this.panel35);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel31.Location = new System.Drawing.Point(0, 157);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(814, 35);
            this.panel31.TabIndex = 31;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.dateTimePicker1);
            this.panel32.Controls.Add(this.panel108);
            this.panel32.Controls.Add(this.panel89);
            this.panel32.Controls.Add(this.label2);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel32.Location = new System.Drawing.Point(120, 0);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(694, 34);
            this.panel32.TabIndex = 5;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker1.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.dateTimePicker1.Location = new System.Drawing.Point(7, 7);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(687, 29);
            this.dateTimePicker1.TabIndex = 10;
            // 
            // panel108
            // 
            this.panel108.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel108.Location = new System.Drawing.Point(0, 7);
            this.panel108.Name = "panel108";
            this.panel108.Size = new System.Drawing.Size(7, 27);
            this.panel108.TabIndex = 7;
            // 
            // panel89
            // 
            this.panel89.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel89.Location = new System.Drawing.Point(0, 0);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(694, 7);
            this.panel89.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.label2.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 23);
            this.label2.TabIndex = 3;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.label3);
            this.panel33.Controls.Add(this.panel34);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(120, 34);
            this.panel33.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.label3.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(70, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 23);
            this.label3.TabIndex = 9;
            this.label3.Text = "DOB :  ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel34
            // 
            this.panel34.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel34.Location = new System.Drawing.Point(0, 0);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(120, 7);
            this.panel34.TabIndex = 3;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel35.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel35.Location = new System.Drawing.Point(0, 34);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(814, 1);
            this.panel35.TabIndex = 1;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.panel27);
            this.panel26.Controls.Add(this.panel28);
            this.panel26.Controls.Add(this.panel30);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel26.Location = new System.Drawing.Point(0, 122);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(814, 35);
            this.panel26.TabIndex = 16;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.customTextBox4);
            this.panel27.Controls.Add(this.program);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(120, 0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(694, 34);
            this.panel27.TabIndex = 5;
            // 
            // customTextBox4
            // 
            this.customTextBox4.BackColor = System.Drawing.Color.White;
            this.customTextBox4.BorderColor = System.Drawing.Color.White;
            this.customTextBox4.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox4.BorderSize = 0;
            this.customTextBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox4.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox4.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox4.Location = new System.Drawing.Point(0, 0);
            this.customTextBox4.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox4.Multiline = false;
            this.customTextBox4.Name = "customTextBox4";
            this.customTextBox4.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox4.PasswordChar = false;
            this.customTextBox4.Size = new System.Drawing.Size(694, 38);
            this.customTextBox4.TabIndex = 0;
            this.customTextBox4.Tag = "1";
            this.customTextBox4.Texts = "Enter Father\'s Name";
            this.customTextBox4.UnderlinedStyle = false;
            this.customTextBox4.Enter += new System.EventHandler(this.customTextBox4_Enter);
            this.customTextBox4.Leave += new System.EventHandler(this.customTextBox4_Leave);
            // 
            // program
            // 
            this.program.AutoSize = true;
            this.program.Dock = System.Windows.Forms.DockStyle.Left;
            this.program.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.program.Location = new System.Drawing.Point(0, 0);
            this.program.Name = "program";
            this.program.Size = new System.Drawing.Size(0, 23);
            this.program.TabIndex = 3;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.label12);
            this.panel28.Controls.Add(this.panel29);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel28.Location = new System.Drawing.Point(0, 0);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(120, 34);
            this.panel28.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Right;
            this.label12.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(19, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 23);
            this.label12.TabIndex = 9;
            this.label12.Text = "Father Name : ";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel29
            // 
            this.panel29.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel29.Location = new System.Drawing.Point(0, 0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(120, 7);
            this.panel29.TabIndex = 3;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel30.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel30.Location = new System.Drawing.Point(0, 34);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(814, 1);
            this.panel30.TabIndex = 1;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Controls.Add(this.panel23);
            this.panel21.Controls.Add(this.panel25);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel21.Location = new System.Drawing.Point(0, 87);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(814, 35);
            this.panel21.TabIndex = 15;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.customTextBox3);
            this.panel22.Controls.Add(this.credit);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(120, 0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(694, 34);
            this.panel22.TabIndex = 5;
            // 
            // customTextBox3
            // 
            this.customTextBox3.BackColor = System.Drawing.Color.White;
            this.customTextBox3.BorderColor = System.Drawing.Color.White;
            this.customTextBox3.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox3.BorderSize = 0;
            this.customTextBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox3.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox3.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox3.Location = new System.Drawing.Point(0, 0);
            this.customTextBox3.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox3.Multiline = false;
            this.customTextBox3.Name = "customTextBox3";
            this.customTextBox3.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox3.PasswordChar = false;
            this.customTextBox3.Size = new System.Drawing.Size(694, 38);
            this.customTextBox3.TabIndex = 0;
            this.customTextBox3.Tag = "1";
            this.customTextBox3.Texts = "Enter Mother\'s Name";
            this.customTextBox3.UnderlinedStyle = false;
            this.customTextBox3.Enter += new System.EventHandler(this.customTextBox3_Enter);
            this.customTextBox3.Leave += new System.EventHandler(this.customTextBox3_Leave);
            // 
            // credit
            // 
            this.credit.AutoSize = true;
            this.credit.Dock = System.Windows.Forms.DockStyle.Left;
            this.credit.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.credit.Location = new System.Drawing.Point(0, 0);
            this.credit.Name = "credit";
            this.credit.Size = new System.Drawing.Size(0, 23);
            this.credit.TabIndex = 3;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.label10);
            this.panel23.Controls.Add(this.panel24);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel23.Location = new System.Drawing.Point(0, 0);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(120, 34);
            this.panel23.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Right;
            this.label10.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(16, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 23);
            this.label10.TabIndex = 9;
            this.label10.Text = "Mother Name : ";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel24
            // 
            this.panel24.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel24.Location = new System.Drawing.Point(0, 0);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(120, 7);
            this.panel24.TabIndex = 3;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel25.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel25.Location = new System.Drawing.Point(0, 34);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(814, 1);
            this.panel25.TabIndex = 1;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Controls.Add(this.panel18);
            this.panel16.Controls.Add(this.panel20);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(0, 52);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(814, 35);
            this.panel16.TabIndex = 14;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.customTextBox2);
            this.panel17.Controls.Add(this.cgpa);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(120, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(694, 34);
            this.panel17.TabIndex = 5;
            // 
            // customTextBox2
            // 
            this.customTextBox2.BackColor = System.Drawing.Color.White;
            this.customTextBox2.BorderColor = System.Drawing.Color.White;
            this.customTextBox2.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox2.BorderSize = 0;
            this.customTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox2.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox2.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox2.Location = new System.Drawing.Point(0, 0);
            this.customTextBox2.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox2.Multiline = false;
            this.customTextBox2.Name = "customTextBox2";
            this.customTextBox2.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox2.PasswordChar = false;
            this.customTextBox2.Size = new System.Drawing.Size(694, 38);
            this.customTextBox2.TabIndex = 0;
            this.customTextBox2.Tag = "1";
            this.customTextBox2.Texts = "Enter Student Name";
            this.customTextBox2.UnderlinedStyle = false;
            this.customTextBox2.Enter += new System.EventHandler(this.customTextBox2_Enter);
            this.customTextBox2.Leave += new System.EventHandler(this.customTextBox2_Leave);
            // 
            // cgpa
            // 
            this.cgpa.AutoSize = true;
            this.cgpa.Dock = System.Windows.Forms.DockStyle.Left;
            this.cgpa.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.cgpa.Location = new System.Drawing.Point(0, 0);
            this.cgpa.Name = "cgpa";
            this.cgpa.Size = new System.Drawing.Size(0, 23);
            this.cgpa.TabIndex = 3;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.label8);
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel18.Location = new System.Drawing.Point(0, 0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(120, 34);
            this.panel18.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Right;
            this.label8.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(11, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 23);
            this.label8.TabIndex = 5;
            this.label8.Text = "Student Name : ";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel19
            // 
            this.panel19.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel19.Location = new System.Drawing.Point(0, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(120, 7);
            this.panel19.TabIndex = 4;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel20.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel20.Location = new System.Drawing.Point(0, 34);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(814, 1);
            this.panel20.TabIndex = 1;
            // 
            // panel131
            // 
            this.panel131.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(177)))), ((int)(((byte)(25)))));
            this.panel131.Controls.Add(this.label1);
            this.panel131.Controls.Add(this.panel151);
            this.panel131.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel131.Location = new System.Drawing.Point(0, 0);
            this.panel131.Name = "panel131";
            this.panel131.Size = new System.Drawing.Size(814, 52);
            this.panel131.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(307, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(344, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "Update/Delete Student";
            // 
            // panel151
            // 
            this.panel151.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel151.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel151.Location = new System.Drawing.Point(0, 51);
            this.panel151.Name = "panel151";
            this.panel151.Size = new System.Drawing.Size(814, 1);
            this.panel151.TabIndex = 1;
            // 
            // RemoveStudent
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(834, 1055);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel5);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RemoveStudent";
            this.Text = "RemoveStudent";
            this.Load += new System.EventHandler(this.RemoveStudent_Load);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel138.ResumeLayout(false);
            this.panel139.ResumeLayout(false);
            this.panel139.PerformLayout();
            this.panel141.ResumeLayout(false);
            this.panel141.PerformLayout();
            this.panel132.ResumeLayout(false);
            this.panel133.ResumeLayout(false);
            this.panel133.PerformLayout();
            this.panel135.ResumeLayout(false);
            this.panel135.PerformLayout();
            this.panel125.ResumeLayout(false);
            this.panel126.ResumeLayout(false);
            this.panel126.PerformLayout();
            this.panel128.ResumeLayout(false);
            this.panel128.PerformLayout();
            this.panel119.ResumeLayout(false);
            this.panel120.ResumeLayout(false);
            this.panel120.PerformLayout();
            this.panel122.ResumeLayout(false);
            this.panel122.PerformLayout();
            this.panel114.ResumeLayout(false);
            this.panel115.ResumeLayout(false);
            this.panel115.PerformLayout();
            this.panel116.ResumeLayout(false);
            this.panel116.PerformLayout();
            this.panel109.ResumeLayout(false);
            this.panel110.ResumeLayout(false);
            this.panel110.PerformLayout();
            this.panel111.ResumeLayout(false);
            this.panel111.PerformLayout();
            this.panel99.ResumeLayout(false);
            this.panel100.ResumeLayout(false);
            this.panel100.PerformLayout();
            this.panel105.ResumeLayout(false);
            this.panel105.PerformLayout();
            this.panel90.ResumeLayout(false);
            this.panel91.ResumeLayout(false);
            this.panel91.PerformLayout();
            this.panel92.ResumeLayout(false);
            this.panel92.PerformLayout();
            this.panel82.ResumeLayout(false);
            this.panel83.ResumeLayout(false);
            this.panel83.PerformLayout();
            this.panel85.ResumeLayout(false);
            this.panel85.PerformLayout();
            this.panel76.ResumeLayout(false);
            this.panel77.ResumeLayout(false);
            this.panel77.PerformLayout();
            this.panel79.ResumeLayout(false);
            this.panel79.PerformLayout();
            this.panel53.ResumeLayout(false);
            this.panel54.ResumeLayout(false);
            this.panel54.PerformLayout();
            this.panel56.ResumeLayout(false);
            this.panel56.PerformLayout();
            this.panel42.ResumeLayout(false);
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.panel63.ResumeLayout(false);
            this.panel64.ResumeLayout(false);
            this.panel64.PerformLayout();
            this.panel66.ResumeLayout(false);
            this.panel66.PerformLayout();
            this.panel69.ResumeLayout(false);
            this.panel70.ResumeLayout(false);
            this.panel70.PerformLayout();
            this.panel72.ResumeLayout(false);
            this.panel72.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.panel49.ResumeLayout(false);
            this.panel49.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel131.ResumeLayout(false);
            this.panel131.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel7;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button loginBtn;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel138;
        private System.Windows.Forms.Panel panel139;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Panel panel140;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel141;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Panel panel142;
        private System.Windows.Forms.Panel panel143;
        private System.Windows.Forms.Panel panel132;
        private System.Windows.Forms.Panel panel133;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Panel panel134;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel panel135;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Panel panel136;
        private System.Windows.Forms.Panel panel137;
        private System.Windows.Forms.Panel panel125;
        private System.Windows.Forms.Panel panel126;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Panel panel127;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel128;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel129;
        private System.Windows.Forms.Panel panel130;
        private System.Windows.Forms.Panel panel119;
        private System.Windows.Forms.Panel panel120;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Panel panel121;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel122;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel123;
        private System.Windows.Forms.Panel panel124;
        private System.Windows.Forms.Panel panel114;
        private System.Windows.Forms.Panel panel115;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox6;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel116;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel117;
        private System.Windows.Forms.Panel panel118;
        private System.Windows.Forms.Panel panel109;
        private System.Windows.Forms.Panel panel110;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel111;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel112;
        private System.Windows.Forms.Panel panel113;
        private System.Windows.Forms.Panel panel99;
        private System.Windows.Forms.Panel panel100;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel panel101;
        private System.Windows.Forms.Panel panel102;
        private System.Windows.Forms.Panel panel103;
        private System.Windows.Forms.Panel panel104;
        private System.Windows.Forms.Panel panel105;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel106;
        private System.Windows.Forms.Panel panel107;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel98;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.Panel panel96;
        private System.Windows.Forms.Panel panel95;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.Panel panel94;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel panel108;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox4;
        private System.Windows.Forms.Label program;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox3;
        private System.Windows.Forms.Label credit;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox2;
        private System.Windows.Forms.Label cgpa;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel131;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel151;
    }
}