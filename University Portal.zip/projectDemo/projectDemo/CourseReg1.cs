﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class CourseReg1 : Form
    {
        public CourseReg1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private Form activeForm = null;
        private void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel1.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }

        private void CourseReg1_Load(object sender, EventArgs e)
        {
            Connection.OpenConection();

            SqlCommand sqlCmdUsers = new SqlCommand("SELECT * FROM users WHERE Id=@Id", Connection.sqlCon);

            sqlCmdUsers.Parameters.AddWithValue("@Id", Form1.id);

            SqlDataReader users;

            users = sqlCmdUsers.ExecuteReader();

            while (users.Read())
            {
                label6.Text = users["name"].ToString().Trim();
                label5.Text = users["Id"].ToString().Trim();
                label7.Text = users["cgpa"].ToString().Trim();
                label8.Text = users["credit"].ToString().Trim();
            }

            Connection.CloseConnection();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            openChildForm(new CourseReg2());
        }
    }
}
