﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class teachersProfile : Form
    {
        public teachersProfile()
        {
            InitializeComponent();
        }

        private void teachersProfile_Load(object sender, EventArgs e)
        {
            Connection.OpenConection();

            SqlCommand sqlCmdUsers = new SqlCommand("SELECT * FROM Teachers WHERE Id=@Id", Connection.sqlCon);

            sqlCmdUsers.Parameters.AddWithValue("@Id", Form1.id);

            SqlDataReader users;

            users = sqlCmdUsers.ExecuteReader();

            while (users.Read())
            {
                name.Text = users["name"].ToString().Trim();
                studentId.Text = users["Id"].ToString().Trim();
                fatherName.Text = users["fatherName"].ToString().Trim();
                motherName.Text = users["motherName"].ToString().Trim();
                dob.Text = users["dob"].ToString().Trim();
                sex.Text = users["gender"].ToString().Trim();
                permanentAddress.Text = users["permanentAddress"].ToString().Trim();
                presentAddress.Text = users["presentAddress"].ToString().Trim();
                verifiedContact.Text = users["contactNumber"].ToString().Trim();
                verifiedEmail.Text = users["emailAddress"].ToString().Trim();
                nationality.Text = users["nationality"].ToString().Trim();
                religion.Text = users["religion"].ToString().Trim();
                maritalStatus.Text = users["maritalStatus"].ToString().Trim();
                bloodGroup.Text = users["bloodGroup"].ToString().Trim();
                admissionDate.Text = users["joiningDate"].ToString().Trim();
                degree.Text = users["degree"].ToString().Trim();
                accountNumber.Text = users["accountNumber"].ToString().Trim();
            }

            Connection.CloseConnection();
        }
    }
}
