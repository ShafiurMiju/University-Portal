﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class showTeacher : Form
    {
        public showTeacher()
        {
            InitializeComponent();
        }

        public void teacherDataShow(string q, DataGridView g)
        {
            Connection.OpenConection();

            SqlDataAdapter sqldpt = new SqlDataAdapter(q, Connection.sqlCon);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            g.DataSource = dt;
            Connection.CloseConnection();
        }

        public void search(DataGridView d, string q)
        {
            Connection.OpenConection();

            SqlDataAdapter sqldpt = new SqlDataAdapter(q, Connection.sqlCon);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            d.DataSource = dt;
            Connection.CloseConnection();


            if (customTextBox1.Texts == "Search Here")
            {
                SqlDataAdapter sqldptAgain = new SqlDataAdapter("SELECT * FROM Teachers", Connection.sqlCon);

                Connection.OpenConection();
                sqldptAgain.Fill(dt);
                d.DataSource = dt;
                Connection.CloseConnection();
            }
        }

        private void customTextBox1__TextChanged(object sender, EventArgs e)
        {
            search(dataGridView1, "SELECT * FROM Teachers WHERE Id LIKE '" + customTextBox1.Texts + "%'");
        }

        private void customTextBox1_Enter(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "Search Here")
            {
                customTextBox1.Texts = "";
                customTextBox1.ForeColor = Color.Black;
            }
        }

        private void customTextBox1_Leave(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "")
            {
                customTextBox1.Texts = "Search Here";
                customTextBox1.ForeColor = Color.DimGray;

            }
        }

        private void showTeacher_Load(object sender, EventArgs e)
        {
            teacherDataShow("SELECT * FROM Teachers", dataGridView1);
        }
    }
}
