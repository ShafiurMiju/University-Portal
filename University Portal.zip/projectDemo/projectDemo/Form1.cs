﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using System.Data.SqlClient;
using Microsoft.PowerBI.Api.Models;

namespace projectDemo
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public static string id;

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
            (int Left, int Top, int Right, int Bottom, int Width, int Height);

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);
        public Form1()
        {
            InitializeComponent();
            customizeDesign();
            this.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.Width, this.Height, 20, 20));
            loginBtn.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, loginBtn.Width, loginBtn.Height, 7, 7));
        }

        private void customizeDesign()
        {
            panel19.Visible = false;
            panel1.Height = 390;
            panel22.Height = 8;
            panel23.Height = 10;
        }

        private void hideDesign()
        {
            if (panel19.Visible == false)
                panel19.Visible = true;
        }

        private void hideDesign1()
        {
            if (panel22.Visible == false)
                panel22.Visible = true;
        }

        private void hideDesign2()
        {
            if (panel23.Visible == false)
                panel23.Visible = true;
                
        }

        private void showDesign(Panel p)
        {
            if (p.Visible == false)
            {
                p.Visible = true;
            }
        }
        private void showDesign1(Panel p1)
        {
            if (p1.Visible == false)
            {
                p1.Visible = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {            
            try
            {
                if (Connection.sqlCon.State == ConnectionState.Closed)
                    Connection.OpenConection();

                String queryUsers = "SELECT COUNT(*) FROM Users WHERE Id=@Id AND password=@password";
                String queryTeachers = "SELECT COUNT(*) FROM Teachers WHERE Id=@Id AND password=@password";
                String queryAdmin = "SELECT COUNT(*) FROM Admin WHERE Id=@Id AND password=@password";

                SqlCommand sqlCmdUsers = new SqlCommand(queryUsers, Connection.sqlCon);
                sqlCmdUsers.CommandType = CommandType.Text;
                sqlCmdUsers.Parameters.AddWithValue("@Id", customTextBox1.Texts);
                sqlCmdUsers.Parameters.AddWithValue("@password", customTextBox2.Texts);
                int Users = Convert.ToInt32(sqlCmdUsers.ExecuteScalar());

                SqlCommand sqlCmdTeachers = new SqlCommand(queryTeachers, Connection.sqlCon);
                sqlCmdTeachers.CommandType = CommandType.Text;
                sqlCmdTeachers.Parameters.AddWithValue("@Id", customTextBox1.Texts.ToString());
                sqlCmdTeachers.Parameters.AddWithValue("@password", customTextBox2.Texts);
                int Teachers = Convert.ToInt32(sqlCmdTeachers.ExecuteScalar());

                SqlCommand sqlCmdAdmin = new SqlCommand(queryAdmin, Connection.sqlCon);
                sqlCmdAdmin.CommandType = CommandType.Text;
                sqlCmdAdmin.Parameters.AddWithValue("@Id", customTextBox1.Texts);
                sqlCmdAdmin.Parameters.AddWithValue("@password", customTextBox2.Texts);
                int Admin = Convert.ToInt32(sqlCmdAdmin.ExecuteScalar());

                try
                {
                    if (Users == 1)
                    {
                        id = customTextBox1.Texts;
                        this.Hide();
                        Form2 f2 = new Form2();
                        f2.ShowDialog();

                    }

                    else if(Teachers == 1)
                    {
                        id = customTextBox1.Texts;
                        this.Hide();
                        Form3 f3 = new Form3();
                        f3.ShowDialog();
                    }

                    else if (Admin == 1)
                    {
                        id = customTextBox1.Texts;
                        this.Hide();
                        Admin admin = new Admin();
                        admin.ShowDialog();
                    }

                    else if (customTextBox1.Texts == "User Name" || customTextBox2.Texts == "Password")
                    {
                        if (customTextBox1.Texts == "User Name" && customTextBox2.Texts == "Password")
                        {
                            panel22.Height = 26;
                            label9.Visible = true;
                            panel23.Height = 26;
                            label12.Visible = true;

                            if (panel19.Visible == true)
                                panel1.Height = 550;
                            else
                                panel1.Height = 422;
                        }
                        else if (customTextBox1.Texts == "User Name")
                        {
                            panel22.Height = 26;
                            label9.Visible = true;

                            if (panel19.Visible == true)
                                panel1.Height = 534;
                            else
                                panel1.Height = 406;
                        }
                        else if (customTextBox2.Texts == "Password")
                        {
                            panel23.Height = 26;
                            label12.Visible = true;

                            if (panel19.Visible == true)
                                panel1.Height = 534;
                            else
                                panel1.Height = 406;
                        }

                    }

                    else
                    {
                        panel1.Height = 520;
                        customTextBox2.Texts = "Password";
                        customTextBox2.PasswordChar = false;
                        customTextBox2.ForeColor = Color.DimGray;
                        showDesign(panel19);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            catch (Exception ex)
            {
                if (customTextBox1.Texts == "User Name" || customTextBox2.Texts == "Password")
                {
                    if (customTextBox1.Texts == "User Name" && customTextBox2.Texts == "Password")
                    {
                        panel22.Height = 26;
                        label9.Visible = true;
                        panel23.Height = 26;
                        label12.Visible = true;

                        if (panel19.Visible == true)
                            panel1.Height = 550;
                        else
                            panel1.Height = 422;
                    }
                    else if (customTextBox1.Texts == "User Name")
                    {
                        panel22.Height = 26;
                        label9.Visible = true;

                        if (panel19.Visible == true)
                            panel1.Height = 534;
                        else
                            panel1.Height = 406;
                    }
                    else if (customTextBox2.Texts == "Password")
                    {
                        panel23.Height = 26;
                        label12.Visible = true;

                        if (panel19.Visible == true)
                            panel1.Height = 534;
                        else
                            panel1.Height = 406;
                    }

                }

                else
                {
                    panel1.Height = 520;
                    customTextBox2.Texts = "Password";
                    customTextBox2.PasswordChar = false;
                    customTextBox2.ForeColor = Color.DimGray;
                    showDesign(panel19);
                }
            }
            finally
            {
                Connection.CloseConnection();
            }

        }

        private void customTextBox1__TextChanged(object sender, EventArgs e)
        {
            if (label9.Visible == true)
            {
                label9.Visible = false; 
                panel22.Height = 10;
                if (panel19.Visible == true)
                {
                    if (label12.Visible == true)
                        panel1.Height = 534;
                    else
                        panel1.Height = 520;
                }
                else if(label12.Visible == true)
                    panel1.Height = 406;
                else
                    panel1.Height = 390;
            }
        }

        private void customTextBox2__TextChanged(object sender, EventArgs e)
        {
            if (label12.Visible == true)
            {
                label12.Visible = false;
                panel23.Height = 10;
                if (panel19.Visible == true)
                {
                    if (label9.Visible == true)
                        panel1.Height = 534;
                    else
                        panel1.Height = 520;
                }
                else if (label9.Visible == true)
                    panel1.Height = 406;
                else
                    panel1.Height = 390;
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            //button1.BackColor = Color.BlueViolet;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            //button1.BackColor = Color.Blue;
        }

        private void customTextBox1_Enter(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "User Name")
            {
                customTextBox1.Texts = "";
                customTextBox1.ForeColor = Color.Black; 
            }
        }

        private void customTextBox1_Leave(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "")
            {
                customTextBox1.Texts = "User Name";
                customTextBox1.ForeColor = Color.DimGray;
            }
        }

        private void customTextBox2_Enter(object sender, EventArgs e)
        {
            if (customTextBox2.Texts == "Password")
            {
                customTextBox2.Texts = "";
                customTextBox2.ForeColor = Color.Black;
                customTextBox2.PasswordChar = true;
            }
        }

        private void customTextBox2_Leave(object sender, EventArgs e)
        {
       
            if (customTextBox2.Texts == "")
            {
                customTextBox2.Texts = "Password";
                customTextBox2.ForeColor = Color.DimGray;
                customTextBox2.PasswordChar = false;
            }
        }
        private void panel12_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, 0xA1, 0x2, 0);
            }
        }

        private void panel12_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //panel1.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width, Height, 40, 40));
        }

        private void loginBtn_Paint(object sender, PaintEventArgs e)
        {

        }

        private void linkLabel1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ForgetPass forgetPass = new ForgetPass();
            this.Hide();
            forgetPass.ShowDialog();
        }
    }
   
}
