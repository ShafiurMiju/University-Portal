﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class FirstPage : Form
    {

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
            (int Left, int Top, int Right, int Bottom, int Width, int Height);
        public FirstPage()
        {
            InitializeComponent();
        }

        public void SelectedShow(string q, DataGridView g)
        {
            Connection.OpenConection();

            SqlCommand sqlCmdUsers = new SqlCommand(q, Connection.sqlCon);

            sqlCmdUsers.Parameters.AddWithValue("@Id", Form1.id);

            SqlDataAdapter sqldpt = new SqlDataAdapter(sqlCmdUsers);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            g.DataSource = dt;
            Connection.CloseConnection();
        }

        private void FirstPage_Load(object sender, EventArgs e)
        {
            button10.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, button10.Width, button10.Height, 7, 7));
            button1.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 7, 7));

            SelectedShow("SELECT CousreName, Section FROM SelectedCourse WHERE Id=@Id", dataGridView1);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            CourseReg1 cr = new CourseReg1();
            cr.ShowDialog();
        }
    }
}
