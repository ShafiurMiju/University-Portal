﻿using DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Interface
{
    public interface IInfo
    {
        List<Info> Get();
        int Insert(Info i1);
        void Update(Info i1);
        void Delete(Info i1);
    }
}
