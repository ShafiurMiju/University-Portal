﻿using DAL.Entities;
using DAL.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Tables
{
    public class Infos : IInfo
    {
        public void Delete(Info i1)
        {
            //function to delete into database
            Connection.OpenConection();

            SqlCommand sqlcmdAdd = new SqlCommand("delete from CourseReg where SI = '" + i1.SI + "'", Connection.sqlCon);
            sqlcmdAdd.ExecuteNonQuery();
            Connection.CloseConnection();
        }

        public List<Info> Get()
        {
            Connection.OpenConection();

            string q1 = "Select * From CourseReg";

            SqlCommand cmd = new SqlCommand(q1, Connection.sqlCon);

            List<Info> data = new List<Info>();

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Info temp = new Info();
                temp.SI = reader.GetInt32(reader.GetOrdinal("SI"));
                temp.CourseName = reader.GetString(reader.GetOrdinal("CourseName"));
                temp.Section = reader.GetString(reader.GetOrdinal("Section"));
                temp.Faculty = reader.GetString(reader.GetOrdinal("Faculty"));

                data.Add(temp);

            }

            Connection.CloseConnection();

            return data;
        }

        public int Insert(Info i1)
        {
            //function to insert into database
            String queryUsersAdd = "INSERT INTO CourseReg VALUES(@SI, @CourseName, @Section, @Faculty)";

            SqlCommand sqlcmdAdd = new SqlCommand(queryUsersAdd, Connection.sqlCon);

            sqlcmdAdd.Parameters.AddWithValue("@SI", i1.SI);
            sqlcmdAdd.Parameters.AddWithValue("@CourseName", i1.CourseName);
            sqlcmdAdd.Parameters.AddWithValue("@Section", i1.Section);
            sqlcmdAdd.Parameters.AddWithValue("@Faculty", i1.Faculty);

            Connection.OpenConection();

            int a = sqlcmdAdd.ExecuteNonQuery();

            sqlcmdAdd.Dispose();
            return a;
        }

        public void Update(Info i1)
        {
            //function to update into database
            Connection.OpenConection();

            SqlCommand sqlcmdAdd = new SqlCommand("update CourseReg set CourseName=@CourseName, Section=@Section, Faculty=@Faculty where SI = '" + i1.SI + "'", Connection.sqlCon);

            sqlcmdAdd.Parameters.AddWithValue("@CourseName", i1.CourseName);
            sqlcmdAdd.Parameters.AddWithValue("@Section", i1.Section);
            sqlcmdAdd.Parameters.AddWithValue("@Faculty", i1.Faculty);

            sqlcmdAdd.ExecuteNonQuery();
            Connection.CloseConnection();
        }
    }
}
