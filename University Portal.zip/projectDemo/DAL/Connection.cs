﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Connection
    {
        public static SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

        public static void OpenConection()
        {
            if (Connection.sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }

        }

        public static void CloseConnection()
        {
            sqlCon.Close();
        }
    }
}
