﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Entities
{
    public class Info
    {
        public int SI { get; set; }
        public  string CourseName { get; set; }
        public string Section { get; set; }
        public string Faculty { get; set; }
    }
}
